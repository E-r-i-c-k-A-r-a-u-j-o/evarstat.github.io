from PyQt6.QtWidgets import QToolBar, QWidget
from PyQt6.QtCore import QCoreApplication, QTimer, QPoint, Qt, QSize, QTranslator, QSettings
from PyQt6.QtGui import QPainter, QColor, QIcon, QAction
import random
import math
import os
from styles import TOOLBAR_STYLESHEET

__name__ = "Confeti de Celebración"
__version__ = "1.0.0"
__author__ = "Gina Gutierrez"
__description__ = "Lanza confeti animado sobre la ventana para celebrar tus logros."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Confeti de Celebración")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Lanza confeti animado sobre la ventana para celebrar tus logros.")

class ConfettiWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.confetti = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_confetti)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
        self.hide()

    def start(self):
        if self.parent():
            self.resize(self.parent().size())
        shapes = ["circle", "square", "triangle", "star"]
        self.confetti = [
            {
                "x": random.randint(0, self.width()),
                "y": random.randint(-50, 0),
                "vx": random.uniform(-1, 1),
                "vy": random.uniform(2, 5),
                "color": QColor(random.choice([
                    "#FF5E5B", "#D7263D", "#3F88C5", "#F49D37", "#444059",
                    "#43AA8B", "#FFD23F", "#F25F5C", "#E27D60", "#85E3FF"
                ])),
                "shape": random.choice(shapes)
            }
            for _ in range(140)
        ]
        self.show()
        self.raise_()
        self.timer.start(30)

    def update_confetti(self):
        for c in self.confetti:
            c["x"] += c["vx"]
            c["y"] += c["vy"]
        self.confetti = [c for c in self.confetti if c["y"] < self.height()]
        self.update()
        if not self.confetti:
            self.timer.stop()
            self.hide()

    def paintEvent(self, event):
        painter = QPainter(self)
        for c in self.confetti:
            painter.setBrush(c["color"])
            painter.setPen(Qt.PenStyle.NoPen)
            x, y = int(c["x"]), int(c["y"])
            size = 14
            if c["shape"] == "circle":
                painter.drawEllipse(QPoint(x, y), size // 2, size // 2)
            elif c["shape"] == "square":
                painter.drawRect(x - size // 2, y - size // 2, size, size)
            elif c["shape"] == "triangle":
                points = [
                    QPoint(x, y - size // 2),
                    QPoint(x - size // 2, y + size // 2),
                    QPoint(x + size // 2, y + size // 2)
                ]
                painter.drawPolygon(*points)
            elif c["shape"] == "star":
                points = []
                for i in range(5):
                    angle = i * 2 * math.pi / 5 - math.pi / 2
                    outer = QPoint(
                        x + int(math.cos(angle) * size // 2),
                        y + int(math.sin(angle) * size // 2)
                    )
                    angle += math.pi / 5
                    inner = QPoint(
                        x + int(math.cos(angle) * size // 4),
                        y + int(math.sin(angle) * size // 4)
                    )
                    points.append(outer)
                    points.append(inner)
                painter.drawPolygon(*points)

def register_plugin(main_window):
    toolbar = QToolBar(QCoreApplication.translate("MainWindow", "Celebrar"))
    toolbar.setObjectName("plugin_toolbar_confetti")
    toolbar.setIconSize(QSize(34, 30))
    main_window.addToolBar(toolbar)
    toolbar.setStyleSheet(TOOLBAR_STYLESHEET)

    icon_path = os.path.join(os.path.dirname(__file__), "confetti.png")
    confetti_action = QAction(
        QIcon(icon_path) if os.path.exists(icon_path) else QIcon(),
        QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"),
        main_window
    )
    confetti_action.setToolTip(QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"))

    if not hasattr(main_window, "_confetti_widget"):
        main_window._confetti_widget = ConfettiWidget(main_window)
        main_window._confetti_widget.resize(main_window.size())
        old_resize_event = getattr(main_window, "resizeEvent", None)
        def new_resize_event(event):
            main_window._confetti_widget.resize(main_window.size())
            if old_resize_event:
                old_resize_event(event)
        main_window.resizeEvent = new_resize_event

    confetti_action.triggered.connect(lambda: main_window._confetti_widget.start())
    toolbar.addAction(confetti_action)

    # Establecer el cursor tipo mano para el botón de confeti
    widget = toolbar.widgetForAction(confetti_action)
    if widget is not None:
        widget.setCursor(Qt.CursorShape.PointingHandCursor)

    # Guardar referencias para traducción dinámica
    toolbar._confetti_action = confetti_action
    toolbar._update_texts = lambda: update_toolbar_texts(toolbar)

    return toolbar

def update_toolbar_texts(toolbar):
    toolbar.setWindowTitle(QCoreApplication.translate("MainWindow", "Celebrar"))
    if hasattr(toolbar, "_confetti_action"):
        toolbar._confetti_action.setText(QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"))
        toolbar._confetti_action.setToolTip(QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"))

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator
            mw = QCoreApplication.instance().activeWindow()
            if mw:
                for tb in getattr(mw, "findChildren", lambda x: [])(QToolBar):
                    if tb.objectName() == "plugin_toolbar_confetti" and hasattr(tb, "_update_texts"):
                        tb._update_texts()

load_plugin_translator()