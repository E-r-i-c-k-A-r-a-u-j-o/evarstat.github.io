from PyQt6.QtWidgets import QToolBar, QWidget
from PyQt6.QtCore import QCoreApplication, QTimer, QPoint, Qt, QSize
from PyQt6.QtGui import QPainter, QColor, QIcon, QAction
import random
import math
import os

__name__ = "Confeti de Celebración"
__version__ = "1.0.0"
__author__ = "Gina Gutiérrez"
__description__ = "Lanza confeti animado sobre la ventana para celebrar tus logros."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Confeti de Celebración")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Lanza confeti animado sobre la ventana para celebrar tus logros.")

class ConfettiWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.confetti = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_confetti)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
        self.hide()

    def start(self):
        # Asegura que el widget tenga el tamaño de la ventana principal
        if self.parent():
            self.resize(self.parent().size())
        shapes = ["circle", "square", "triangle", "star"]
        self.confetti = [
            {
                "x": random.randint(0, self.width()),
                "y": random.randint(-50, 0),
                "vx": random.uniform(-1, 1),
                "vy": random.uniform(2, 5),
                "color": QColor(random.choice([
                    "#FF5E5B", "#D7263D", "#3F88C5", "#F49D37", "#444059",
                    "#43AA8B", "#FFD23F", "#F25F5C", "#E27D60", "#85E3FF"
                ])),
                "shape": random.choice(shapes)
            }
            for _ in range(140)
        ]
        self.show()
        self.raise_()
        self.timer.start(30)

    def update_confetti(self):
        for c in self.confetti:
            c["x"] += c["vx"]
            c["y"] += c["vy"]
        self.confetti = [c for c in self.confetti if c["y"] < self.height()]
        self.update()
        if not self.confetti:
            self.timer.stop()
            self.hide()

    def paintEvent(self, event):
        painter = QPainter(self)
        for c in self.confetti:
            painter.setBrush(c["color"])
            painter.setPen(Qt.PenStyle.NoPen)
            x, y = int(c["x"]), int(c["y"])
            size = 14
            if c["shape"] == "circle":
                painter.drawEllipse(QPoint(x, y), size // 2, size // 2)
            elif c["shape"] == "square":
                painter.drawRect(x - size // 2, y - size // 2, size, size)
            elif c["shape"] == "triangle":
                points = [
                    QPoint(x, y - size // 2),
                    QPoint(x - size // 2, y + size // 2),
                    QPoint(x + size // 2, y + size // 2)
                ]
                painter.drawPolygon(*points)
            elif c["shape"] == "star":
                points = []
                for i in range(5):
                    angle = i * 2 * math.pi / 5 - math.pi / 2
                    outer = QPoint(
                        x + int(math.cos(angle) * size // 2),
                        y + int(math.sin(angle) * size // 2)
                    )
                    angle += math.pi / 5
                    inner = QPoint(
                        x + int(math.cos(angle) * size // 4),
                        y + int(math.sin(angle) * size // 4)
                    )
                    points.append(outer)
                    points.append(inner)
                painter.drawPolygon(*points)

def register_plugin(main_window):
    toolbar = QToolBar(QCoreApplication.translate("MainWindow", "Celebrar"))
    toolbar.setObjectName("plugin_toolbar_confetti")
    toolbar.setIconSize(QSize(34, 30))
    main_window.addToolBar(toolbar)
    toolbar.setStyleSheet("""
    QToolButton {
        background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                        stop:0 #ffffff, stop:1 #e9ecef);
        border: 1px solid #b0b4b8;
        border-radius: 6px;
        padding: 3px 5px;
        margin-right: 11px;
        margin-top: 0px; 
        margin-bottom: 3px; 
        color: #343a40;
        font-weight: 500;
        /* Sombra interior para efecto 3D */
        box-shadow: 0 2px 4px rgba(0,0,0,0.10);
    }
    QToolButton:hover {
        background-color: #e9f5ff;
        border: 1px solid #66b3ff;
        color: #0056b3;
    }
    QToolButton:pressed {
        border: 7px solid #eee;
        border-radius: 6px;

        /* Sombra interna simulando presión */
        box-shadow: inset 0 2px 6px rgba(0, 0, 0, 0.25),
                    inset 0 -1px 3px rgba(255, 255, 255, 0.2),
                    0 0 0 1px rgba(0, 86, 179, 0.25);

        /* Ligero cambio de escala simulando presión */
        transform: scale(0.98);

        transition: all 0.1s ease-in-out;
    }
""")
    
    icon_path = os.path.join(os.path.dirname(__file__), "confetti.png")
    confetti_action = QAction(
        QIcon(icon_path),
        QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"),
        main_window
    )
    confetti_action.setToolTip(QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"))

    if not hasattr(main_window, "_confetti_widget"):
        main_window._confetti_widget = ConfettiWidget(main_window)
        main_window._confetti_widget.resize(main_window.size())
        main_window.resizeEvent = lambda event: main_window._confetti_widget.resize(main_window.size())

    confetti_action.triggered.connect(lambda: main_window._confetti_widget.start())
    toolbar.addAction(confetti_action)
    return toolbar