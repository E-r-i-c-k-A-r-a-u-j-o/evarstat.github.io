import sys
import time
import re
from xml.etree import ElementTree as ET
from deep_translator import GoogleTranslator

# Función para proteger placeholders (%1, %2, %n)
def proteger_placeholders(texto):
    return re.sub(r'%\d', lambda m: f'PLACEHOLDER{m.group(0)[1]}', texto)

# Función para restaurar placeholders
def restaurar_placeholders(texto):
    return re.sub(r'PLACEHOLDER(\d)', r'%\1', texto)

# Función robusta de traducción
def traducir(texto, source_lang, target_lang):
    if not texto:
        return ""

    espacios_inicio = len(texto) - len(texto.lstrip())
    espacios_final = len(texto) - len(texto.rstrip())

    texto_protegido = proteger_placeholders(texto)

    try:
        texto_traducido = GoogleTranslator(source=source_lang, target=target_lang).translate(texto_protegido)
    except Exception as e:
        print(f"[ERROR] al traducir '{texto}': {e}")
        return texto  # Devolver original si falla

    texto_traducido = restaurar_placeholders(texto_traducido)

    texto_traducido = " " * espacios_inicio + texto_traducido.strip() + " " * espacios_final

    return texto_traducido

# Función que traduce un archivo .ts a un idioma destino
def traducir_ts(archivo_origen, archivo_destino, source_lang, target_lang):
    print(f"\n=== Traduciendo {source_lang} → {target_lang} ({archivo_destino}) ===\n")

    tree = ET.parse(archivo_origen)
    root = tree.getroot()

    cache_traducciones = {}

    total_mensajes = sum(
        1 for context in root.findall("context")
          for message in context.findall("message")
          if message.find("source") is not None and
             message.find("translation") is not None and
             message.find("translation").attrib.get("type") == "unfinished"
    )
    procesados = 0

    for context in root.findall("context"):
        for message in context.findall("message"):
            source = message.find("source")
            translation = message.find("translation")

            if source is not None and translation is not None and translation.attrib.get("type") == "unfinished":
                texto_original = source.text or ""

                if texto_original in cache_traducciones:
                    texto_traducido = cache_traducciones[texto_original]
                else:
                    texto_traducido = traducir(texto_original, source_lang, target_lang)
                    cache_traducciones[texto_original] = texto_traducido
                    time.sleep(0.5)  # Evitar bloqueos

                print(f"[{procesados+1}/{total_mensajes}] '{texto_original}' → '{texto_traducido}'")
                translation.text = texto_traducido
                translation.attrib.pop("type", None)
                procesados += 1

    tree.write(archivo_destino, encoding="utf-8", xml_declaration=True)
    print(f"✅ Traducción completa para {target_lang}. Archivo guardado como '{archivo_destino}'.")

# Función principal batch
def main(archivo_origen, idiomas_destino):
    source_lang = "es"  # Español como idioma de origen

    for target_lang in idiomas_destino:
        archivo_destino = f"{target_lang}.ts"
        traducir_ts(archivo_origen, archivo_destino, source_lang, target_lang)

# Uso del script
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python traducir_ts_batch.py archivo_origen.ts idioma_destino1 [idioma_destino2 ... idioma_destinoN]")
        print("Ejemplo: python traducir_ts_batch.py es.ts en fr de it")
        sys.exit(1)

    archivo_origen = sys.argv[1]
    idiomas_destino = sys.argv[2:]

    main(archivo_origen, idiomas_destino)
