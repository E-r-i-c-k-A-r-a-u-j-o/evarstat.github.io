from PyQt6.QtWidgets import QToolBar, QWidget
from PyQt6.QtCore import QCoreApplication, QTimer, QPoint, Qt, QSize, QTranslator, QSettings
from PyQt6.QtGui import QPainter, QColor, QIcon, QAction, QPainterPath, QFont
import random
import math
import os
from styles import TOOLBAR_STYLESHEET

__name__ = "Confeti de Celebración"
__version__ = "2.0.0"
__author__ = "Gina Gutierrez"
__description__ = "Lanza confeti animado sobre la ventana para celebrar tus logros."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Confeti de Celebración")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Lanza confeti animado sobre la ventana para celebrar tus logros.")

class ConfettiWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.confetti = []
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_confetti)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool)
        self.hide()

    def start(self):
        if self.parent():
            self.resize(self.parent().size())
        shapes = ["circle", "square", "triangle", "star", "heart", "diamond", "moon", "emoji"]
        pastel_colors = [
            "#FFB3BA", "#FFDFBA", "#FFFFBA", "#BAFFC9", "#BAE1FF",
            "#B5B9FF", "#FFB5F7", "#B5FFD9", "#FFF7B5", "#B5FFF7"
        ]
        neon_colors = [
            "#FF00FF", "#00FFFF", "#39FF14", "#FF3131", "#FFFB00",
            "#FF6EC7", "#FF61A6", "#00FFB3", "#FFB347", "#BFFF00"
        ]
        all_colors = pastel_colors + neon_colors
        emojis = ["🎉", "✨", "🥳", "🎊", "💖", "⭐"]

        self.confetti = [
            {
                "x": random.randint(0, self.width()),
                "y": random.randint(-50, 0),
                "vx": random.uniform(-2, 2),
                "vy": random.uniform(2, 5),
                "color": QColor(random.choice(all_colors)),
                "shape": random.choice(shapes),
                "angle": random.uniform(0, 2 * math.pi),
                "rotation": random.uniform(-0.2, 0.2),
                "bounce": False,
                "opacity": 1.0,
                "emoji": random.choice(emojis)
            }
            for _ in range(160)
        ]
        self.show()
        self.raise_()
        self.timer.start(30)

    def update_confetti(self):
        for c in self.confetti:
            c["x"] += c["vx"]
            c["y"] += c["vy"]
            c["angle"] += c["rotation"]
            # Rebote simple en el fondo
            if c["y"] > self.height() - 16 and not c["bounce"]:
                c["vy"] = -c["vy"] * 0.4
                c["vx"] *= 0.7
                c["bounce"] = True
            elif c["y"] < self.height() - 16:
                c["bounce"] = False
            # Desvanecimiento suave al llegar al fondo
            if c["y"] > self.height() - 40:
                c["opacity"] -= 0.04
            else:
                c["opacity"] = min(1.0, c["opacity"] + 0.02)
        self.confetti = [c for c in self.confetti if c["opacity"] > 0]
        self.update()
        if not self.confetti:
            self.timer.stop()
            self.hide()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        for c in self.confetti:
            painter.save()
            painter.setOpacity(max(0, min(1, c["opacity"])))
            painter.translate(int(c["x"]), int(c["y"]))
            painter.rotate(math.degrees(c["angle"]))
            painter.setBrush(c["color"])
            painter.setPen(Qt.PenStyle.NoPen)
            size = 16
            if c["shape"] == "circle":
                painter.drawEllipse(QPoint(0, 0), size // 2, size // 2)
            elif c["shape"] == "square":
                painter.drawRect(-size // 2, -size // 2, size, size)
            elif c["shape"] == "triangle":
                points = [
                    QPoint(0, -size // 2),
                    QPoint(-size // 2, size // 2),
                    QPoint(size // 2, size // 2)
                ]
                painter.drawPolygon(*points)
            elif c["shape"] == "star":
                points = []
                for i in range(5):
                    angle = i * 2 * math.pi / 5 - math.pi / 2
                    outer = QPoint(
                        int(math.cos(angle) * size // 2),
                        int(math.sin(angle) * size // 2)
                    )
                    angle += math.pi / 5
                    inner = QPoint(
                        int(math.cos(angle) * size // 4),
                        int(math.sin(angle) * size // 4)
                    )
                    points.append(outer)
                    points.append(inner)
                painter.drawPolygon(*points)
            elif c["shape"] == "heart":
                path = QPainterPath()
                path.moveTo(0, 0)
                path.cubicTo(-size // 2, -size // 2, -size, size // 3, 0, size)
                path.cubicTo(size, size // 3, size // 2, -size // 2, 0, 0)
                painter.drawPath(path)
            elif c["shape"] == "diamond":
                points = [
                    QPoint(0, -size // 2),
                    QPoint(-size // 3, 0),
                    QPoint(0, size // 2),
                    QPoint(size // 3, 0)
                ]
                painter.drawPolygon(*points)
            elif c["shape"] == "moon":
                path = QPainterPath()
                path.moveTo(0, 0)
                path.arcTo(-size//2, -size//2, size, size, 30, 300)
                path.arcTo(-size//4, -size//2, size, size, 210, -300)
                painter.drawPath(path)
            elif c["shape"] == "emoji":
                font = QFont()
                font.setPointSize(14)
                painter.setFont(font)
                painter.drawText(-size//2, size//2, c["emoji"])
            painter.restore()

def register_plugin(main_window):
    toolbar = QToolBar(QCoreApplication.translate("MainWindow", "Celebrar"))
    toolbar.setObjectName("plugin_toolbar_confetti")
    toolbar.setIconSize(QSize(34, 30))
    main_window.addToolBar(toolbar)
    toolbar.setStyleSheet(TOOLBAR_STYLESHEET)

    icon_path = os.path.join(os.path.dirname(__file__), "confetti.png")
    confetti_action = QAction(
        QIcon(icon_path),
        QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"),
        main_window
    )
    confetti_action.setToolTip(QCoreApplication.translate("MainWindow", "¡Lanzar confeti!"))

    if not hasattr(main_window, "_confetti_widget"):
        main_window._confetti_widget = ConfettiWidget(main_window)
        main_window._confetti_widget.resize(main_window.size())
        main_window.resizeEvent = lambda event: main_window._confetti_widget.resize(main_window.size())

    confetti_action.triggered.connect(lambda: main_window._confetti_widget.start())
    toolbar.addAction(confetti_action)

    for action in toolbar.actions():
        widget = toolbar.widgetForAction(action)
        if widget is not None:
            widget.setCursor(Qt.CursorShape.PointingHandCursor)

    return toolbar

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator

load_plugin_translator()