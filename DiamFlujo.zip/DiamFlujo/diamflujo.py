from PyQt6.QtWidgets import (QWidget,
    QMenu, QMainWindow, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton,
    QGraphicsView, QGraphicsScene, QGraphicsRectItem, QGraphicsTextItem, QGraphicsLineItem, QFileDialog, QMessageBox,
    QGroupBox, QTextEdit
)
from PyQt6.QtCore import QCoreApplication, Qt, QRectF, QPointF, QTranslator, QSettings
from PyQt6.QtGui import QAction, QIcon, QPen, QBrush, QColor, QPixmap, QPainter, QPolygonF, QFontMetrics
import os
from PyQt6.QtWidgets import QInputDialog

import math

__name__ = "Diagrama de flujo"
__version__ = "1.0.0"
__author__ = "EVAR Stat"
__description__ = "Permite crear diagramas de flujo de decisiones y guardarlos como imagen."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Diagrama de flujo")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Permite crear diagramas de flujo de decisiones y guardarlos como imagen.")

style = """
    QGroupBox {
        border: 1px solid #2B90B9;
        border-radius: 8px;
        margin-top: 10px;
    }
    QGroupBox:title {
        subcontrol-origin: margin;
        subcontrol-position: top center;
        color: black;
        padding-top: 30px;  /* Baja el título dentro del cuadro */
        padding-bottom: 2px;
        padding-left: 3px;
        padding-right: 3px;
    }
"""

class HoverLineItem(QGraphicsLineItem):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setAcceptHoverEvents(True)
        self.default_pen = QPen(Qt.GlobalColor.black, 2)
        self.hover_pen = QPen(Qt.GlobalColor.blue, 4)
        self.setPen(self.default_pen)
        self.setFlag(QGraphicsLineItem.GraphicsItemFlag.ItemIsSelectable, True)

    def hoverEnterEvent(self, event):
        self.setPen(self.hover_pen)
        super().hoverEnterEvent(event)

    def hoverLeaveEvent(self, event):
        self.setPen(self.default_pen)
        super().hoverLeaveEvent(event)

def register_plugin(main_window):
    icon_path = os.path.join(os.path.dirname(__file__), "flow.png")
    if os.path.exists(icon_path):
        menu = QMenu(QIcon(icon_path), QCoreApplication.translate("diagrama_flujo", "Diagrama de flujo"), main_window)
    else:
        menu = QMenu(QCoreApplication.translate("diagrama_flujo", "Diagrama de flujo"), main_window)
    menu.setObjectName("plugin_menu_diagrama_flujo")

    action_flujo = QAction(QCoreApplication.translate("diagrama_flujo", "Crear"), main_window)
    action_flujo.triggered.connect(lambda: show_flowchart_dialog(main_window))
    menu.addAction(action_flujo)

    main_window.menuBar().addMenu(menu)
    return menu

class FlowchartDialog(QMainWindow):  # <--- Cambia QDialog por QMainWindow
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(QCoreApplication.translate("diagrama_flujo", "Creador de diagrama de flujo"))
        self.setGeometry(100, 100, 1000, 600)

        # Panel central y layout principal
        central_widget = QWidget()
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        btn_style = "font-size: 12px; height: 18px;"

        # --- Grupo: Nodos ---
        group_nodo = QGroupBox(QCoreApplication.translate("diagrama_flujo", "Nodos"))
        group_nodo.setStyleSheet(style)
        nodo_layout = QVBoxLayout(group_nodo)
        self.text_input = QLineEdit()
        self.text_input.setPlaceholderText(QCoreApplication.translate("diagrama_flujo", "Texto del nodo"))
        self.text_input.setStyleSheet(btn_style)
        self.add_node_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Agregar"))
        self.add_node_btn.setStyleSheet(btn_style)
        self.add_node_btn.clicked.connect(self.add_node)
        self.edit_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Editar"))
        self.edit_btn.setStyleSheet(btn_style)
        self.edit_btn.clicked.connect(self.edit_node)
        self.delete_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Eliminar"))
        self.delete_btn.setStyleSheet(btn_style)
        self.delete_btn.clicked.connect(self.delete_node)
        nodo_layout.addWidget(self.text_input)
        nodo_layout.addWidget(self.add_node_btn)
        nodo_layout.addWidget(self.edit_btn)
        nodo_layout.addWidget(self.delete_btn)

        # --- Grupo: Estilo de nodo ---
        group_estilo = QGroupBox(QCoreApplication.translate("diagrama_flujo", "Estilo"))
        group_estilo.setStyleSheet(style)
        estilo_layout = QVBoxLayout(group_estilo)
        self.color_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Color texto"))
        self.color_btn.setStyleSheet(btn_style)
        self.color_btn.clicked.connect(self.change_color)
        self.color_bg_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Color fondo"))
        self.color_bg_btn.setStyleSheet(btn_style)
        self.color_bg_btn.clicked.connect(self.change_bg_color)
        self.bold_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Negrita"))
        self.bold_btn.setStyleSheet(btn_style)
        self.bold_btn.clicked.connect(self.set_bold)
        self.italic_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Cursiva"))
        self.italic_btn.setStyleSheet(btn_style)
        self.italic_btn.clicked.connect(self.set_italic)
        estilo_layout.addWidget(self.color_btn)
        estilo_layout.addWidget(self.color_bg_btn)
        estilo_layout.addWidget(self.bold_btn)
        estilo_layout.addWidget(self.italic_btn)

        # --- Grupo: Conexiones ---
        group_conex = QGroupBox(QCoreApplication.translate("diagrama_flujo", "Conexiones"))
        group_conex.setStyleSheet(style)
        conex_layout = QVBoxLayout(group_conex)
        self.connect_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Conectar nodos"))
        self.connect_btn.setStyleSheet(btn_style)
        self.connect_btn.clicked.connect(self.connect_nodes)
        self.line_width_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Grosor línea"))
        self.line_width_btn.setStyleSheet(btn_style)
        self.line_width_btn.clicked.connect(self.set_line_width)
        self.delete_arrow_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Eliminar flecha"))
        self.delete_arrow_btn.setStyleSheet(btn_style)
        self.delete_arrow_btn.clicked.connect(self.delete_arrow)
        conex_layout.addWidget(self.connect_btn)
        conex_layout.addWidget(self.line_width_btn)
        conex_layout.addWidget(self.delete_arrow_btn)

        # --- Grupo: Archivo ---
        group_archivo = QGroupBox(QCoreApplication.translate("diagrama_flujo", "Archivo"))
        group_archivo.setStyleSheet(style)
        archivo_layout = QVBoxLayout(group_archivo)
        self.save_btn = QPushButton(QCoreApplication.translate("diagrama_flujo", "Guardar imagen"))
        self.save_btn.setStyleSheet(btn_style)
        self.save_btn.clicked.connect(self.save_as_image)
        archivo_layout.addWidget(self.save_btn)

        central_widget = QWidget()
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(8)

        # Panel lateral de controles (vertical)
        controls_widget = QWidget()
        controls_layout = QVBoxLayout(controls_widget)
        controls_layout.setSpacing(8)
        controls_layout.addWidget(group_nodo)
        controls_layout.addWidget(group_estilo)
        controls_layout.addWidget(group_conex)
        controls_layout.addWidget(group_archivo)
        controls_layout.addStretch(1)

        main_layout.addWidget(controls_widget, 0)  # Panel lateral izquierdo

        # Área de trabajo
        group_trabajo = QGroupBox("")  # Sin título
        group_trabajo.setStyleSheet(style)
        trabajo_layout = QVBoxLayout(group_trabajo)
        trabajo_layout.setContentsMargins(0, 0, 0, 0)  # <--- Elimina los márgenes internos
        trabajo_layout.setSpacing(0)

        self.scene = QGraphicsScene()
        self.view = QGraphicsView(self.scene)
        self.view.setStyleSheet("background: #e9ecef; border: none;")  # Opcional: sin borde extra
        trabajo_layout.addWidget(self.view)

        main_layout.addWidget(group_trabajo, 1)  # Área de trabajo a la derecha con borde


        self.setCentralWidget(central_widget)
        self.nodes = []
        self.selected_nodes = []
        self.lines = []
        self.connections = []

        self.scene.selectionChanged.connect(self.update_selected_nodes)
        self.showMaximized()

    def add_node(self):
        text = self.text_input.text().strip()
        if not text:
            return

        # Medir el ancho y alto del texto con saltos de línea automáticos
        font = self.font()
        metrics = QFontMetrics(font)
        max_width = 180  # Ancho máximo del nodo
        text_item = QGraphicsTextItem(text)
        text_item.setFont(font)
        text_item.setTextWidth(max_width - 20)  # Limita el ancho del texto, deja margen

        # Calcula el tamaño del rectángulo según el texto
        text_rect = text_item.boundingRect()
        width = max(120, text_rect.width() + 20)
        height = max(50, text_rect.height() + 20)

        x = 50 + len(self.nodes) * 150
        y = 100

        rect = QGraphicsRectItem(QRectF(x, y, width, height))
        rect.setBrush(QBrush(QColor("#e9ecef")))
        rect.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemIsMovable, True)
        rect.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemIsSelectable, True)
        rect.setFlag(QGraphicsRectItem.GraphicsItemFlag.ItemSendsGeometryChanges, True)
        self.scene.addItem(rect)

        # Ajusta la posición del texto dentro del nodo
        text_item.setParentItem(rect)
        text_item.setPos(x + 10, y + 10)
        text_item.setDefaultTextColor(Qt.GlobalColor.black)
        text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        rect.text_item = text_item
        self.nodes.append(rect)
        self.text_input.clear()

        # Permitir doble clic para editar texto
        text_item.mouseDoubleClickEvent = lambda event, ti=text_item: self.edit_text_item(ti)
        rect.itemChange = self.make_item_change(rect)

    def make_item_change(self, rect):
        # Esta función devuelve un método que actualiza conexiones al mover el nodo
        def item_change(change, value):
            from PyQt6.QtWidgets import QGraphicsItem
            if change == QGraphicsItem.GraphicsItemChange.ItemPositionChange:
                self.update_connections(rect)
            return QGraphicsRectItem.itemChange(rect, change, value)
        return item_change

    def update_connections(self, moved_node):
        for conn in self.connections:
            line, arrow, label, node1, node2 = conn
            if moved_node in (node1, node2):
                p1 = node1.sceneBoundingRect().center()
                p2 = node2.sceneBoundingRect().center()
                line.setLine(p1.x(), p1.y(), p2.x(), p2.y())
                # Actualizar flecha
                self.update_arrow(arrow, p1, p2)
                # Actualizar etiqueta
                if label:
                    label.setPos((p1.x() + p2.x()) / 2, (p1.y() + p2.y()) / 2 - 15)

    def update_selected_nodes(self):
        self.selected_nodes = [item for item in self.scene.selectedItems() if isinstance(item, QGraphicsRectItem)]

    def edit_text_item(self, text_item):
        text_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        text_item.setFocus()
        text_item.focusOutEvent = lambda event, ti=text_item: self.finish_edit_text_item(ti)

    def finish_edit_text_item(self, text_item):
        text_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        # Autoajustar tamaño del nodo al terminar de editar
        rect = text_item.parentItem()
        if rect:
            text_rect = text_item.boundingRect()
            width = max(120, text_rect.width() + 20)
            height = max(50, text_rect.height() + 20)
            rect.setRect(rect.rect().x(), rect.rect().y(), width, height)
            text_item.setTextWidth(width - 20)

    def edit_label_text_item(self, label_item):
        label_item.setTextInteractionFlags(Qt.TextInteractionFlag.TextEditorInteraction)
        label_item.setFocus()
        label_item.focusOutEvent = lambda event, ti=label_item: self.finish_edit_label_text_item(ti)

    def finish_edit_label_text_item(self, label_item):
        label_item.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)

    def edit_node(self):
        if len(self.selected_nodes) != 1:
            return
        rect = self.selected_nodes[0]
        self.edit_text_item(rect.text_item)

    def delete_node(self):
        for rect in self.selected_nodes:
            # Eliminar líneas conectadas
            for line in self.lines[:]:
                if hasattr(line, "from_node") and (line.from_node == rect or line.to_node == rect):
                    self.scene.removeItem(line)
                    self.lines.remove(line)
            self.scene.removeItem(rect)
            self.nodes.remove(rect)
        self.selected_nodes = []

    def change_color(self):
        if len(self.selected_nodes) != 1:
            return
        from PyQt6.QtWidgets import QColorDialog
        color = QColorDialog.getColor()
        if color.isValid():
            self.selected_nodes[0].text_item.setDefaultTextColor(color)

    def change_bg_color(self):
        if len(self.selected_nodes) != 1:
            return
        from PyQt6.QtWidgets import QColorDialog
        color = QColorDialog.getColor()
        if color.isValid():
            self.selected_nodes[0].setBrush(QBrush(color))

    def set_bold(self):
        if len(self.selected_nodes) != 1:
            return
        font = self.selected_nodes[0].text_item.font()
        font.setBold(not font.bold())
        self.selected_nodes[0].text_item.setFont(font)

    def set_italic(self):
        if len(self.selected_nodes) != 1:
            return
        font = self.selected_nodes[0].text_item.font()
        font.setItalic(not font.italic())
        self.selected_nodes[0].text_item.setFont(font)

    def set_line_width(self):
        if not self.lines:
            return
        dialog = QInputDialog(self)
        dialog.setWindowTitle("EVAR Stat")
        dialog.setLabelText(QCoreApplication.translate("diagrama_flujo", "Nuevo grosor:"))
        dialog.setInputMode(QInputDialog.InputMode.IntInput)
        dialog.setIntRange(1, 10)
        dialog.setIntValue(2)
        dialog.setOkButtonText(QCoreApplication.translate("diagrama_flujo", "Aceptar"))
        dialog.setCancelButtonText(QCoreApplication.translate("diagrama_flujo", "Cancelar"))
        # Aplica estilo a los botones
        dialog.setStyleSheet("""
            QPushButton {
                font-size: 12px;
                height: 18px;
                margin-right: 12px;
                background: #3399ff;
                color: #fff;
            }
            QPushButton:last-child {
                margin-right: 0;
            }
        """)
        if dialog.exec():
            width = dialog.intValue()
            for line in self.lines:
                if line.isSelected() or (
                    hasattr(line, "from_node") and line.from_node in self.selected_nodes
                ) or (
                    hasattr(line, "to_node") and line.to_node in self.selected_nodes
                ):
                    pen = line.pen()

    def connect_nodes(self):
        if len(self.selected_nodes) != 2:
            QMessageBox.warning(self, "EVAR Stat", QCoreApplication.translate("diagrama_flujo", "Selecciona dos nodos para conectar."))
            return
        node1, node2 = self.selected_nodes
        p1 = node1.sceneBoundingRect().center()
        p2 = node2.sceneBoundingRect().center()
        # Línea principal
        line = HoverLineItem(p1.x(), p1.y(), p2.x(), p2.y())
        line.setFlag(QGraphicsLineItem.GraphicsItemFlag.ItemIsSelectable, True)
        pen = QPen(Qt.GlobalColor.black, 2)
        line.setPen(pen)
        line.from_node = node1
        line.to_node = node2
        self.scene.addItem(line)
        # Flecha
        arrow = self.add_arrow(p1, p2)
        # Etiqueta personalizada
        dialog = QInputDialog(self)
        dialog.setWindowTitle("EVAR Stat")
        dialog.setLabelText(QCoreApplication.translate("diagrama_flujo", "Texto de la la relación (opcional):"))
        dialog.setOkButtonText(QCoreApplication.translate("diagrama_flujo", "Aceptar"))
        dialog.setCancelButtonText(QCoreApplication.translate("diagrama_flujo", "Cancelar"))

        # Detectar tema desde la ventana principal
        main_window = self.parent()
        theme = getattr(main_window, "current_theme", "light")
        if theme == "dark":
            dialog.setStyleSheet("""
                QLineEdit, QTextEdit {
                    font-size: 12px;
                    background: #333;
                    color: #fff;
                }
                QPushButton {
                    font-size: 12px;
                    height: 18px;
                    margin-right: 12px;
                    background: #3399ff;
                    color: #fff;
                }
                QPushButton:last-child {
                    margin-right: 0;
                }
                QLabel {
                    color: #fff;
                }
                QDialog {
                    background: #222;
                }
            """)
            for child in dialog.findChildren((QLineEdit, QTextEdit)):
                child.setFixedHeight(50)
        else:
            dialog.setStyleSheet("""
                QLineEdit, QTextEdit {
                    font-size: 12px;
                    background: #fff;
                    color: #000;
                }
                QPushButton {
                    font-size: 12px;
                    height: 18px;
                    margin-right: 12px;
                    background: #007BFF;
                    color: #fff;
                }
                QPushButton:last-child {
                    margin-right: 0;
                }
                QLabel {
                    color: #000;
                }
                QDialog {
                    background: #e9ecef;
                }
            """)
            for child in dialog.findChildren((QLineEdit, QTextEdit)):
                child.setFixedHeight(40)

        label = None
        if dialog.exec():
            text = dialog.textValue()
            if text.strip():
                label = QGraphicsTextItem(text)
                label.setDefaultTextColor(Qt.GlobalColor.darkBlue)
                label.setPos((p1.x() + p2.x()) / 2, (p1.y() + p2.y()) / 2 - 15)
                self.scene.addItem(label)
                label.mouseDoubleClickEvent = lambda event, ti=label: self.edit_label_text_item(ti)
        self.connections.append((line, arrow, label, node1, node2))
        self.lines.append(line)
        node1.setSelected(False)
        node2.setSelected(False)

    def add_arrow(self, start, end):
        # Dibuja una flecha en el extremo final de la línea
        angle = math.atan2(end.y() - start.y(), end.x() - start.x())
        arrow_size = 12
        p1 = end
        p2 = QPointF(
            end.x() - arrow_size * math.cos(angle - math.pi / 7),
            end.y() - arrow_size * math.sin(angle - math.pi / 7)
        )
        p3 = QPointF(
            end.x() - arrow_size * math.cos(angle + math.pi / 7),
            end.y() - arrow_size * math.sin(angle + math.pi / 7)
        )
        arrow = self.scene.addPolygon(
            QPolygonF([p1, p2, p3]),  # <-- CORRECTO
            QPen(Qt.GlobalColor.black),
            QBrush(Qt.GlobalColor.black)
        )
        return arrow

    def update_arrow(self, arrow, start, end):
        # Actualiza la posición de la flecha
        angle = math.atan2(end.y() - start.y(), end.x() - start.x())
        arrow_size = 12
        p1 = end
        p2 = QPointF(
            end.x() - arrow_size * math.cos(angle - math.pi / 7),
            end.y() - arrow_size * math.sin(angle - math.pi / 7)
        )
        p3 = QPointF(
            end.x() - arrow_size * math.cos(angle + math.pi / 7),
            end.y() - arrow_size * math.sin(angle + math.pi / 7)
        )
        arrow.setPolygon(QPolygonF([p1, p2, p3]))

    def save_as_image(self):
        file_path, _ = QFileDialog.getSaveFileName(self, QCoreApplication.translate("diagrama_flujo", "Guardar como imagen"), "", "PNG (*.png)")
        if file_path:
            rect = self.scene.itemsBoundingRect()
            image = QPixmap(int(rect.width()) + 20, int(rect.height()) + 20)
            image.fill(Qt.GlobalColor.white)
            painter = QPainter(image)
            self.scene.render(painter, target=rect)
            painter.end()
            image.save(file_path)
            QMessageBox.information(self, "EVAR Stat", QCoreApplication.translate("diagrama_flujo", "Imagen guardada correctamente."))

    def delete_arrow(self):
        # Elimina la flecha (conexión) seleccionada
        selected_lines = [item for item in self.scene.selectedItems() if isinstance(item, QGraphicsLineItem)]
        if not selected_lines:
            QMessageBox.warning(self, "EVAR Stat", QCoreApplication.translate("diagrama_flujo", "Selecciona una flecha para eliminar."))
            return
        for line in selected_lines:
            # Busca la conexión correspondiente
            for conn in self.connections[:]:
                l, arrow, label, node1, node2 = conn
                if l == line:
                    self.scene.removeItem(l)
                    if arrow:
                        self.scene.removeItem(arrow)
                    if label:
                        self.scene.removeItem(label)
                    self.connections.remove(conn)
                    if l in self.lines:
                        self.lines.remove(l)
                    break

def show_flowchart_dialog(main_window):
    win = FlowchartDialog(main_window)
    win.show()

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator

load_plugin_translator()