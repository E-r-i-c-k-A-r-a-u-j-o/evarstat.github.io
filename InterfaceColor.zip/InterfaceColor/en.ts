<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Interface Color</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Allows you to customize the main interface color.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Appearance</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Interface color</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Customize the interface color</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Interface color</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Blue</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Green</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Orange</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>Purple</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Red</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>Turquoise</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>Yellow</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>Pink</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>Gray</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Custom</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Reset</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Select a valid color.</translation>
    </message>
</context>
</TS>
