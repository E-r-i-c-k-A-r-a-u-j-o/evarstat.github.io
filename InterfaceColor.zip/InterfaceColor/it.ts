<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Colore dell’interfaccia</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Consente di personalizzare il colore principale dell’interfaccia.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Aspetto</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Colore dell’interfaccia</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Personalizza il colore dell’interfaccia</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Colore dell’interfaccia</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Personalizzato</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Ripristina</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Seleziona un colore valido.</translation>
    </message>
</context>
</TS>
