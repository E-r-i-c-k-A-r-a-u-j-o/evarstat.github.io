<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko_KR" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>인터페이스 색상</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>인터페이스의 기본 색상을 사용자 지정할 수 있습니다.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>모양</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>인터페이스 색상</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>파랑</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>초록</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>주황</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>보라</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>빨강</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>터키색</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>노랑</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>분홍</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>회색</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>인터페이스 색상 사용자 지정</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>인터페이스 색상</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>사용자 지정</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>재설정</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>유효한 색상을 선택하세요.</translation>
    </message>
</context>
</TS>
