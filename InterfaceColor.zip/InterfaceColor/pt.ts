<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_PT" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Cor da Interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Permite personalizar a cor principal da interface.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Aparência</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Cor da interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Personalizar a cor da interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Cor da interface</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Azul</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Verde</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Laranja</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>Roxo</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Vermelho</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>Turquesa</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>Amarelo</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>Rosa</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>Cinzento</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Personalizado</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Restaurar</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Selecione uma cor válida.</translation>
    </message>
</context>
</TS>
