<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Oberflächenfarbe</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Ermöglicht das Anpassen der Hauptfarbe der Benutzeroberfläche.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Erscheinungsbild</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Oberflächenfarbe</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Oberflächenfarbe anpassen</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Oberflächenfarbe</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Benutzerdefiniert</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Blau</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Grün</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Orange</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>Lila</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Rot</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>Türkis</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>Gelb</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>Rosa</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>Grau</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Zurücksetzen</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Bitte wählen Sie eine gültige Farbe aus.</translation>
    </message>
</context>
</TS>
