<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Couleur de l’interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Permet de personnaliser la couleur principale de l’interface.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Apparence</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Couleur de l’interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Personnaliser la couleur de l’interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Couleur de l’interface</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Personnalisé</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Bleu</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Vert</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Orange</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>Violet</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Rouge</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>Turquoise</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>Jaune</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>Rose</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>Gris</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Réinitialiser</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Sélectionnez une couleur valide.</translation>
    </message>
</context>
</TS>
