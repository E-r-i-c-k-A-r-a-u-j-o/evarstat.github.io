<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>界面颜色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>允许自定义界面的主色调。</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>外观</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>蓝色</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>绿色</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>橙色</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>紫色</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>红色</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>青绿色</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>黄色</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>粉色</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>灰色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>界面颜色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>自定义界面颜色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>界面颜色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>自定义</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>重置</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>请选择有效的颜色。</translation>
    </message>
</context>
</TS>
