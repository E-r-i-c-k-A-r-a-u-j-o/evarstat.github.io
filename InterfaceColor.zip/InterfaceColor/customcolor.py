from PyQt6.QtCore import QCoreApplication, QSettings, Qt, QSize, QTranslator
from PyQt6.QtGui import QColor, QAction, QIcon
from PyQt6.QtWidgets import QDialog, QHBoxLayout, QPushButton, QVBoxLayout, QColorDialog, QMessageBox, QGridLayout, QToolBar
import os
from styles import LIGHT_STYLESHEET, DARK_STYLESHEET, TOOLBAR_STYLESHEET

__name__ = "Color de la Interfaz"
__version__ = "1.0.0"
__author__ = "EVAR Stat"
__description__ = "Permite personalizar el color principal de la interfaz."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Color de la Interfaz")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Permite personalizar el color principal de la interfaz.")

SETTINGS_KEY_COLOR = "ui/custom_base_color"

def _make_palette_icon(base_hex: str) -> QIcon:
    icon_path = os.path.join(os.path.dirname(__file__), "palette.png")
    return QIcon(icon_path)

def register_plugin(main_window):
    toolbar = QToolBar(QCoreApplication.translate("MainWindow", "Apariencia"))
    toolbar.setObjectName("plugin_toolbar_theme")
    toolbar.setIconSize(QSize(34, 30))
    toolbar.setStyleSheet(TOOLBAR_STYLESHEET)
    main_window.addToolBar(toolbar)

    settings = QSettings("EVARStat", "EVARStatApp")
    base_hex = settings.value(SETTINGS_KEY_COLOR, "#007BFF")
    theme_action = QAction(
        _make_palette_icon(base_hex),
        QCoreApplication.translate("MainWindow", "Color de interfaz"),
        main_window
    )
    theme_action.setToolTip(QCoreApplication.translate("MainWindow", "Personalizar el color de la interfaz"))
    theme_action.triggered.connect(lambda: show_color_dialog(main_window))
    toolbar.addAction(theme_action)

    for action in toolbar.actions():
        widget = toolbar.widgetForAction(action)
        if widget is not None:
            widget.setCursor(Qt.CursorShape.PointingHandCursor)
            
    if base_hex:
        apply_custom_colors(main_window, QColor(base_hex))

    return toolbar

def show_color_dialog(main_window):
    dlg = QDialog(main_window)
    dlg.setWindowTitle(QCoreApplication.translate("MainWindow", "Color de la interfaz"))
    v = QVBoxLayout(dlg)
    v.setContentsMargins(20, 20, 20, 20)
    v.setSpacing(12)

    palette = [
        (QCoreApplication.translate("MainWindow", "Azul"), "#007BFF"),
        (QCoreApplication.translate("MainWindow", "Verde"), "#2ecc71"),
        (QCoreApplication.translate("MainWindow", "Naranja"), "#f39c12"),
        (QCoreApplication.translate("MainWindow", "Morado"), "#9b59b6"),
        (QCoreApplication.translate("MainWindow", "Rojo"), "#e74c3c"),
        (QCoreApplication.translate("MainWindow", "Turquesa"), "#1abc9c"),
        (QCoreApplication.translate("MainWindow", "Amarillo"), "#f1c40f"),
        (QCoreApplication.translate("MainWindow", "Rosa"), "#e91e63"),
        (QCoreApplication.translate("MainWindow", "Gris"), "#95a5a6"),
    ]
    grid = QGridLayout()
    grid.setHorizontalSpacing(10)
    grid.setVerticalSpacing(10)

    def on_pick(color: QColor):
        if color and color.isValid():
            apply_custom_colors(main_window, color) 

    def make_palette_btn(name, hexcolor):
        btn = QPushButton(QCoreApplication.translate("MainWindow", name))
        btn.setCursor(Qt.CursorShape.PointingHandCursor)

        base = QColor(hexcolor)
        c0 = base.name()
        light1 = base.lighter(115).name()
        light2 = base.lighter(135).name()
        dark1 = base.darker(120).name()
        dark2 = base.darker(150).name()
        dis1 = base.lighter(160).name()
        dis2 = base.lighter(140).name()
        disb = base.lighter(150).name()

        btn.setStyleSheet(f"""
            QPushButton {{
                /* Cuerpo con gradiente para efecto volumen */
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 {light1}, stop:1 {c0});
                color: #ffffff;
                /* Bisel: claro arriba/izquierda, oscuro abajo/derecha */
                border: 1px solid {dark1};
                border-top-color: {light2};
                border-left-color: {light2};
                border-right-color: {dark2};
                border-bottom-color: {dark2};
                border-radius: 6px;
                padding: 6px 10px;
                min-width: 110px;
            }}
            QPushButton:hover {{
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 {light2}, stop:1 {light1});
            }}
            QPushButton:pressed {{
                /* Simula hundido: invierte bisel y desplaza 1px el contenido */
                padding-top: 7px;
                padding-left: 11px;
                padding-bottom: 5px;
                padding-right: 9px;
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 {c0}, stop:1 {dark1});
                border-top-color: {dark2};
                border-left-color: {dark2};
                border-right-color: {light2};
                border-bottom-color: {light2};
            }}
            QPushButton:disabled {{
                color: rgba(255,255,255,0.7);
                background-color: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                                                  stop:0 {dis1}, stop:1 {dis2});
                border: 1px solid {disb};
            }}
        """)
        btn.clicked.connect(lambda: on_pick(QColor(hexcolor)))
        return btn

    row = col = 0
    for name, hexc in palette:
        grid.addWidget(make_palette_btn(name, hexc), row, col)
        col += 1
        if col >= 3:
            col = 0
            row += 1
    v.addLayout(grid)

    buttons = QHBoxLayout()
    pick_btn = QPushButton(QCoreApplication.translate("MainWindow", "Personalizado"))
    reset_btn = QPushButton(QCoreApplication.translate("MainWindow", "Restablecer"))
    pick_btn.setStyleSheet("font-size: 12px; height: 18px;")
    reset_btn.setStyleSheet("font-size: 12px; height: 18px;")
    buttons.addStretch(1)
    buttons.addWidget(pick_btn)
    buttons.addSpacing(15)
    buttons.addWidget(reset_btn)
    buttons.addStretch(1)
    v.addSpacing(6)
    v.addLayout(buttons)

    def pick_dialog():
        c = QColorDialog.getColor(parent=dlg)
        if c.isValid():
            on_pick(c)

    def on_reset():
        reset_colors(main_window)  

    pick_btn.clicked.connect(pick_dialog)
    reset_btn.clicked.connect(on_reset)

    dlg.exec()

def _hex(qcolor: QColor) -> str:
    return qcolor.name()

def _lighter(qcolor: QColor, factor: int) -> str:
    return qcolor.lighter(factor).name()

def _darker(qcolor: QColor, factor: int) -> str:
    return qcolor.darker(factor).name()

def _replace_many(css: str, mapping: dict) -> str:
    for old, new in mapping.items():
        css = css.replace(old, new)
    return css

def apply_custom_colors(main_window, base_color: QColor):
    if not base_color or not base_color.isValid():
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Seleccione un color válido."))
        return

    primary = _hex(base_color)
    header = _lighter(base_color, 120)
    border = _darker(base_color, 115)
    sel_bg = _lighter(base_color, 180)

    light_map = {
        "#007BFF": primary,
        "#1E90FF": header,
        "#2B90B9": border,
        "#0078D7": border,
        "#66b3ff": _lighter(base_color, 140),
        "#d6eaff": sel_bg,
        "#e0f7fa": _lighter(base_color, 190),
        "#b2ebf2": _lighter(base_color, 175),
    }
    dark_map = {
        "#3399ff": primary,
        "#2177cc": _darker(base_color, 120),
        "#d6eaff": sel_bg,
    }

    new_light = _replace_many(LIGHT_STYLESHEET, light_map)
    new_dark = _replace_many(DARK_STYLESHEET, dark_map)

    new_dark = new_dark.replace("QTextEdit {\n    background-color: #999999;\n    border-radius: 5px;\n    padding: 20px;", 
                               "QTextEdit {\n    background-color: #999999;\n    border-radius: 5px;\n    padding: 20px 10px 20px 20px;")

    main_window.light_stylesheet = new_light
    main_window.dark_stylesheet = new_dark
    if hasattr(main_window, "set_theme"):
        main_window.set_theme(main_window.current_theme)
        if hasattr(main_window, "update_label_styles"):
            main_window.update_label_styles()
    else:
        current = getattr(main_window, "current_theme", "light")
        main_window.setStyleSheet(new_light if current == "light" else new_dark)

    settings = QSettings("EVARStat", "EVARStatApp")
    settings.setValue(SETTINGS_KEY_COLOR, primary)

    if hasattr(main_window, "quick_toolbar"):
        from styles import TOOLBAR_STYLESHEET
        toolbar_css = TOOLBAR_STYLESHEET + export_btn_css(primary)
        main_window.quick_toolbar.setStyleSheet(toolbar_css)

def reset_colors(main_window):
    main_window.light_stylesheet = LIGHT_STYLESHEET
    main_window.dark_stylesheet = DARK_STYLESHEET
    if hasattr(main_window, "set_theme"):
        main_window.set_theme(main_window.current_theme)
        if hasattr(main_window, "update_label_styles"):
            main_window.update_label_styles()
    else:
        current = getattr(main_window, "current_theme", "light")
        main_window.setStyleSheet(LIGHT_STYLESHEET if current == "light" else DARK_STYLESHEET)

    settings = QSettings("EVARStat", "EVARStatApp")
    settings.remove(SETTINGS_KEY_COLOR)

    if hasattr(main_window, "quick_toolbar"):
        from styles import TOOLBAR_STYLESHEET
        main_window.quick_toolbar.setStyleSheet(TOOLBAR_STYLESHEET)

def export_btn_css(base_hex: str) -> str:
    from PyQt6.QtGui import QColor
    base = QColor(base_hex)
    c0 = base.name()
    hover = base.darker(130).name()
    pressed = base.darker(160).name()
    return f"""
    QPushButton.export-btn {{
        background-color: {c0};
        border: 1px solid {c0};
        border-radius: 6px;
        padding: 2px 10px;
        margin-right: 10px;
        color: white;
        font-weight: 600;
        letter-spacing: 0.5px;
        font-size: 12px;
        text-align: center;
    }}
    QPushButton.export-btn:hover {{
        background-color: {hover};
        border: 1px solid {hover};
        color: white;
    }}
    QPushButton.export-btn:pressed {{
        background-color: {pressed};
        color: white;
        border: 1px solid {pressed};
    }}
    QPushButton.export-btn:focus {{
        outline: none;
    }}
    """

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator

load_plugin_translator()