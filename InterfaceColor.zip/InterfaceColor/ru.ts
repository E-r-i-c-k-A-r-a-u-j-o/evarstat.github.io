<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>Цвет интерфейса</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>Позволяет настроить основной цвет интерфейса.</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>Внешний вид</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>Синий</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>Зелёный</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>Оранжевый</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>Фиолетовый</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>Красный</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>Бирюзовый</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>Жёлтый</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>Розовый</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>Серый</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>Цвет интерфейса</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>Настроить цвет интерфейса</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>Цвет интерфейса</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>Пользовательский</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>Сбросить</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>Пожалуйста, выберите допустимый цвет.</translation>
    </message>
</context>
</TS>
