<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP" sourcelanguage="es_ES">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="customcolor.py" line="13"/>
        <source>Color de la Interfaz</source>
        <translation>インターフェースの色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="16"/>
        <source>Permite personalizar el color principal de la interfaz.</source>
        <translation>インターフェースの主要な色をカスタマイズできます。</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="25"/>
        <source>Apariencia</source>
        <translation>外観</translation>
    </message>
    <message>
        <source>Azul</source>
        <translation>青</translation>
    </message>
    <message>
        <source>Verde</source>
        <translation>緑</translation>
    </message>
    <message>
        <source>Naranja</source>
        <translation>オレンジ</translation>
    </message>
    <message>
        <source>Morado</source>
        <translation>紫</translation>
    </message>
    <message>
        <source>Rojo</source>
        <translation>赤</translation>
    </message>
    <message>
        <source>Turquesa</source>
        <translation>ターコイズ</translation>
    </message>
    <message>
        <source>Amarillo</source>
        <translation>黄色</translation>
    </message>
    <message>
        <source>Rosa</source>
        <translation>ピンク</translation>
    </message>
    <message>
        <source>Gris</source>
        <translation>グレー</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="35"/>
        <source>Color de interfaz</source>
        <translation>インターフェースの色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="38"/>
        <source>Personalizar el color de la interfaz</source>
        <translation>インターフェースの色をカスタマイズ</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="49"/>
        <source>Color de la interfaz</source>
        <translation>インターフェースの色</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="140"/>
        <source>Personalizado</source>
        <translation>カスタム</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="141"/>
        <source>Restablecer</source>
        <translation>リセット</translation>
    </message>
    <message>
        <location filename="customcolor.py" line="181"/>
        <source>Seleccione un color válido.</source>
        <translation>有効な色を選択してください。</translation>
    </message>
</context>
</TS>
