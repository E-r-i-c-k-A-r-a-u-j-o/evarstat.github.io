<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="it">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Ricerca Wikipedia</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Consente di cercare un termine e mostrare il significato direttamente da Wikipedia.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>La libreria &apos;wikipedia&apos; non è installata. Si prega di reinstallare il plugin.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Cerca termine:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Termine ambiguo. Opzioni:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>Termine non trovato.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Cerca parola</translation>
    </message>
</context>
</TS>
