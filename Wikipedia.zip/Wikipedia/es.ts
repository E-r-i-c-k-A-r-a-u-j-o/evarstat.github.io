<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="es">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Búsqueda en Wikipedia</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Permite buscar un término y mostrar el significado directamente desde Wikipedia.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Buscar término:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Término ambiguo. Opciones:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>No se encontró el término.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Buscar palabra</translation>
    </message>
</context>
</TS>
