<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="fr">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Recherche Wikipedia</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Permet de rechercher un terme et d&apos;afficher sa signification directement depuis Wikipedia.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>La bibliothèque &apos;wikipedia&apos; n&apos;est pas installée. Veuillez réinstaller le plugin.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Rechercher un terme :</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Terme ambigu. Options :
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>Terme non trouvé.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Rechercher un mot</translation>
    </message>
</context>
</TS>
