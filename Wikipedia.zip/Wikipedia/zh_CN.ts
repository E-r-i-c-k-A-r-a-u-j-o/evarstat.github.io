<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="zh">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>维基百科搜索</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>允许直接从维基百科搜索术语并显示其含义。</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>未安装“wikipedia”库。请重新安装插件。</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>维基百科</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>搜索术语：</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>搜索</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>取消</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>术语不明确。选项：
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>未找到该术语。</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>搜索单词</translation>
    </message>
</context>
</TS>
