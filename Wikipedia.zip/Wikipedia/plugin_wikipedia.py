import os
from PyQt6.QtCore import QCoreApplication, QSettings, QTranslator
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QHBoxLayout, QPushButton, QMessageBox
from PyQt6.QtGui import QAction

__name__ = "Wikipedia Search"
__version__ = "1.0"
__author__ = "EVAR Stat team"
__description__ = "Permite buscar un término y muestrar el significado directamente desde Wikipedia."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Wikipedia Search")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Permite buscar un término y muestrar el significado directamente desde Wikipedia.")

def register_plugin(main_window):
    def buscar_wikipedia():
        load_plugin_translator()  # <-- Esto asegura que el idioma sea el actual de la app
        try:
            try:
                import wikipedia
            except ImportError:
                QMessageBox.critical(
                    main_window,
                    "EVAR Stat",
                    QCoreApplication.translate("Wikipedia", "La librería 'wikipedia' no está instalada. Por favor, reinstala el plugin.")
                )
                return

            # Diálogo personalizado
            dialog = QDialog(main_window)
            dialog.setWindowTitle(QCoreApplication.translate("Wikipedia", "Wikipedia"))
            dialog.setStyleSheet(main_window.styleSheet())
            layout = QVBoxLayout(dialog)
            label = QLabel(QCoreApplication.translate("Wikipedia", "Buscar término:"))
            layout.addWidget(label)
            layout.addSpacing(10)
            term_input = QLineEdit()
            layout.addWidget(term_input)
            btn_layout = QHBoxLayout()
            btn_aceptar = QPushButton(QCoreApplication.translate("Wikipedia", "Buscar"))
            btn_cancelar = QPushButton(QCoreApplication.translate("Wikipedia", "Cancelar"))
            btn_aceptar.setStyleSheet("font-size: 12px; height: 18px;")
            btn_cancelar.setStyleSheet("font-size: 12px; height: 18px;")
            btn_aceptar.clicked.connect(dialog.accept)
            btn_cancelar.clicked.connect(dialog.reject)
            btn_layout.addStretch(1)
            btn_layout.addWidget(btn_aceptar)
            btn_layout.addWidget(btn_cancelar)
            btn_layout.addStretch(1)
            btn_layout.setSpacing(20)
            layout.addLayout(btn_layout)
            dialog.setLayout(layout)
            term_input.setFocus()
            term_input.returnPressed.connect(btn_aceptar.click)
            result = dialog.exec()
            term = term_input.text().strip()
            if result != QDialog.DialogCode.Accepted or not term:
                return

            try:
                lang = QSettings("EVARStat", "EVARStatApp").value("language", "es")
                wikipedia.set_lang(lang)
                summary = wikipedia.summary(term, sentences=3, auto_suggest=True, redirect=True)
                # Mostrar el resultado en el área de resultados principal
                if hasattr(main_window, "result_area"):
                    main_window.result_area.append(summary)
                else:
                    QMessageBox.information(
                        main_window,
                        QCoreApplication.translate("Wikipedia", f"Wikipedia: {term}"),
                        summary
                    )
            except wikipedia.exceptions.DisambiguationError as e:
                opciones = e.options[:5]
                mensaje = QCoreApplication.translate("Wikipedia", "Término ambiguo. Opciones:\n") + "\n".join(opciones)
                if hasattr(main_window, "result_area"):
                    main_window.result_area.setPlainText(mensaje)
                else:
                    QMessageBox.warning(
                        main_window,
                        QCoreApplication.translate("Wikipedia", "Wikipedia"),
                        mensaje
                    )
            except wikipedia.exceptions.PageError:
                mensaje = QCoreApplication.translate("Wikipedia", "No se encontró el término.")
                if hasattr(main_window, "result_area"):
                    main_window.result_area.setPlainText(mensaje)
                else:
                    QMessageBox.warning(
                        main_window,
                        QCoreApplication.translate("Wikipedia", "Wikipedia"),
                        mensaje
                    )
            except Exception as e:
                mensaje = QCoreApplication.translate("Wikipedia", f"Error inesperado: {e}")
                if hasattr(main_window, "result_area"):
                    main_window.result_area.setPlainText(mensaje)
                else:
                    QMessageBox.warning(
                        main_window,
                        QCoreApplication.translate("Wikipedia", "Wikipedia"),
                        mensaje
                    )
        except Exception as e:
            # Captura cualquier error inesperado de compatibilidad, cambios en la API, etc.
            QMessageBox.critical(
                main_window,
                "EVAR Stat",
                QCoreApplication.translate("Wikipedia", f"Ocurrió un error inesperado en el plugin Wikipedia:\n{e}")
            )

    existing_menus = [action.menu() for action in main_window.menuBar().actions()
                     if action.menu() and action.menu().objectName() == "plugin_menu_wikipedia"]

    if existing_menus:
        return existing_menus[0]

    action = QAction(QCoreApplication.translate("Wikipedia", "Buscar palabra"), main_window)
    action.triggered.connect(buscar_wikipedia)
    menu = main_window.menuBar().addMenu(QCoreApplication.translate("Wikipedia", "Wikipedia"))
    menu.setObjectName("plugin_menu_wikipedia")
    menu.addAction(action)
    return menu

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator

load_plugin_translator()