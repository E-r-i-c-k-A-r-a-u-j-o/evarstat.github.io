<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="ru">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Поиск в Википедии</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Позволяет искать термин и показывать значение прямо из Википедии.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>Библиотека &apos;wikipedia&apos; не установлена. Пожалуйста, переустановите плагин.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Википедия</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Поиск термина:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Неоднозначный термин. Варианты:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>Термин не найден.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Поиск слова</translation>
    </message>
</context>
</TS>
