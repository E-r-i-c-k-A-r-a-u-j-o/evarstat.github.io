<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="en">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Wikipedia Search</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Allows you to search for a term and display its meaning directly from Wikipedia.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>The &apos;wikipedia&apos; library is not installed. Please reinstall the plugin.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Search term:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Search</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Ambiguous term. Options:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>Term not found.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Search word</translation>
    </message>
</context>
</TS>
