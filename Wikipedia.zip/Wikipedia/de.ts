<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="de">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>Wikipedia-Suche</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Ermöglicht die Suche nach einem Begriff und zeigt die Bedeutung direkt aus Wikipedia an.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>Die Bibliothek &apos;wikipedia&apos; ist nicht installiert. Bitte installieren Sie das Plugin erneut.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>Wikipedia</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>Begriff suchen:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>Suchen</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>Mehrdeutiger Begriff. Optionen:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>Begriff nicht gefunden.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>Wort suchen</translation>
    </message>
</context>
</TS>
