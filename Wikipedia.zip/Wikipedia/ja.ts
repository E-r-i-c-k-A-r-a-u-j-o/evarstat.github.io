<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="ja">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>ウィキペディア検索</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>Wikipediaから直接用語を検索し、意味を表示できます。</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>&apos;wikipedia&apos;ライブラリがインストールされていません。プラグインを再インストールしてください。</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>ウィキペディア</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>用語を検索：</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>検索</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>曖昧な用語です。オプション：
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>用語が見つかりませんでした。</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>単語を検索</translation>
    </message>
</context>
</TS>
