<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es" sourcelanguage="ko">
<context>
    <name>MainWindow</name>
    <message>
        <source>Wikipedia Search</source>
        <translation>위키백과 검색</translation>
    </message>
    <message>
        <source>Permite buscar un término y muestrar el significado directamente desde Wikipedia.</source>
        <translation>위키백과에서 직접 용어를 검색하고 의미를 표시할 수 있습니다.</translation>
    </message>
</context>
<context>
    <name>Wikipedia</name>
    <message>
        <source>La librería &apos;wikipedia&apos; no está instalada. Por favor, reinstala el plugin.</source>
        <translation>&apos;wikipedia&apos; 라이브러리가 설치되어 있지 않습니다. 플러그인을 다시 설치하십시오.</translation>
    </message>
    <message>
        <source>Wikipedia</source>
        <translation>위키백과</translation>
    </message>
    <message>
        <source>Buscar término:</source>
        <translation>용어 검색:</translation>
    </message>
    <message>
        <source>Buscar</source>
        <translation>검색</translation>
    </message>
    <message>
        <source>Cancelar</source>
        <translation>취소</translation>
    </message>
    <message>
        <source>Término ambiguo. Opciones:
</source>
        <translation>모호한 용어입니다. 옵션:
</translation>
    </message>
    <message>
        <source>No se encontró el término.</source>
        <translation>용어를 찾을 수 없습니다.</translation>
    </message>
    <message>
        <source>Buscar palabra</source>
        <translation>단어 검색</translation>
    </message>
</context>
</TS>
