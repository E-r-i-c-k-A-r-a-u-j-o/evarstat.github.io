# Este archivo es un plugin compatible con EVAR Stat
from PyQt6.QtWidgets import (
    QMenu, QMessageBox, QDialog, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton
)
from PyQt6.QtCore import QCoreApplication, QSettings, QTranslator
from PyQt6.QtGui import QAction, QIcon
import random
import os

__name__ = "Generador de Datos Aleatorios"
__version__ = "2.0.0"
__author__ = "Erick Araujo"
__description__ = "Rellena una columna seleccionada con datos aleatorios (números o categorías)."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Generador de Datos Aleatorios")

def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Rellena una columna seleccionada con datos aleatorios (números o categorías).")

def register_plugin(main_window):
    icon_path = os.path.join(os.path.dirname(__file__), "random.png")
    if os.path.exists(icon_path):
        menu = QMenu(QIcon(icon_path), QCoreApplication.translate("random", "Datos aleatorios"), main_window)
    else:
        menu = QMenu(QCoreApplication.translate("random", "Datos aleatorios"), main_window)
    menu.setObjectName("plugin_menu_random_data")

    action_float = QAction(QCoreApplication.translate("random", "Números"), main_window)
    action_float.triggered.connect(lambda: fill_random_float(main_window))
    menu.addAction(action_float)

    action_cat = QAction(QCoreApplication.translate("random", "Categorías"), main_window)
    action_cat.triggered.connect(lambda: fill_random_cat(main_window))
    menu.addAction(action_cat)

    main_window.menuBar().addMenu(menu)
    return menu

class FloatDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        if parent and hasattr(parent, "current_theme"):
            theme = getattr(parent, "current_theme", "light")
            if theme == "dark":
                self.setStyleSheet(parent.dark_stylesheet)
            else:
                self.setStyleSheet(parent.light_stylesheet)
        self.setWindowTitle(QCoreApplication.translate("random", "Generar números aleatorios"))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        self.min_spin = QLineEdit()
        self.min_spin.setFixedWidth(80)
        self.min_spin.setFixedHeight(40)
        self.max_spin = QLineEdit()
        self.max_spin.setFixedHeight(40)
        self.max_spin.setFixedWidth(80)
        self.n_rows = QLineEdit()
        self.n_rows.setFixedHeight(40)
        l1 = QHBoxLayout()
        l1.addWidget(QLabel(QCoreApplication.translate("random", "Mínimo:")))
        l1.addWidget(self.min_spin)
        l1.addWidget(QLabel(QCoreApplication.translate("random", "Máximo:")))
        l1.addWidget(self.max_spin)
        layout.addLayout(l1)
        l2 = QHBoxLayout()
        l2.addWidget(QLabel(QCoreApplication.translate("random", "Número de filas a rellenar:")))
        l2.addWidget(self.n_rows)
        layout.addLayout(l2)
        btn_layout = QHBoxLayout()
        btn_aceptar = QPushButton(QCoreApplication.translate("random", "Aceptar"))
        btn_cancelar = QPushButton(QCoreApplication.translate("random", "Cancelar"))
        btn_aceptar.setStyleSheet("font-size: 12px; height: 18px;")
        btn_cancelar.setStyleSheet("font-size: 12px; height: 18px;")
        btn_aceptar.clicked.connect(self.accept)
        btn_cancelar.clicked.connect(self.reject)
        btn_layout.addStretch(1)
        btn_layout.addWidget(btn_aceptar)
        btn_layout.addWidget(btn_cancelar)
        btn_layout.addStretch(1)
        btn_layout.setSpacing(25)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

class CatDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        if parent and hasattr(parent, "current_theme"):
            theme = getattr(parent, "current_theme", "light")
            if theme == "dark":
                self.setStyleSheet(parent.dark_stylesheet)
            else:
                self.setStyleSheet(parent.light_stylesheet)
        self.setWindowTitle(QCoreApplication.translate("random", "Generar categorías aleatorias"))
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)
        self.cat_edit = QLineEdit()
        self.cat_edit.setPlaceholderText(QCoreApplication.translate("random", "Separadas por comas"))
        self.cat_edit.setFixedHeight(40)
        self.n_rows = QLineEdit()
        self.n_rows.setFixedHeight(40)
        l1 = QHBoxLayout()
        l1.addWidget(QLabel(QCoreApplication.translate("random", "Categorías:")))
        l1.addWidget(self.cat_edit)
        layout.addLayout(l1)
        l2 = QHBoxLayout()
        l2.addWidget(QLabel(QCoreApplication.translate("random", "Número de filas a rellenar:")))
        l2.addWidget(self.n_rows)
        layout.addLayout(l2)
        btn_layout = QHBoxLayout()
        btn_aceptar = QPushButton(QCoreApplication.translate("random", "Aceptar"))
        btn_cancelar = QPushButton(QCoreApplication.translate("random", "Cancelar"))
        btn_aceptar.setStyleSheet("font-size: 12px; height: 18px;")
        btn_cancelar.setStyleSheet("font-size: 12px; height: 18px;")
        btn_aceptar.clicked.connect(self.accept)
        btn_cancelar.clicked.connect(self.reject)
        btn_layout.addStretch(1)
        btn_layout.addWidget(btn_aceptar)
        btn_layout.addWidget(btn_cancelar)
        btn_layout.addStretch(1)
        btn_layout.setSpacing(25)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

def fill_random_float(main_window):
    col = main_window.table.currentIndex().column()
    if col < 0:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("random", "Selecciona una columna primero."))
        return
    dlg = FloatDialog(main_window)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return
    min_text = dlg.min_spin.text().replace(",", ".")
    max_text = dlg.max_spin.text().replace(",", ".")
    try:
        min_val = float(min_text)
        max_val = float(max_text)
        n_rows = int(dlg.n_rows.text())
    except ValueError:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("random", "Asegúrate de llenar todos los campos correctamente."))
        return
    if "." in max_text:
        clean_text = max_text.rstrip("0").rstrip(".")
        if "." in clean_text:
            decimales = len(clean_text.split(".")[1])
        else:
            decimales = 0
    else:
        decimales = 0
    model = main_window.table.model()
    while model.rowCount() < n_rows:
        model.insertRow(model.rowCount())
    try:
        model.dataChanged.disconnect(main_window.update_occupied_counters)
        model.dataChanged.disconnect(main_window.update_selection_count)
    except Exception:
        pass
    for row in range(n_rows):
        val = random.uniform(min_val, max_val)
        model._df.iat[row, col] = f"{val:.{decimales}f}"
    main_window.table.viewport().update()
    model.dataChanged.connect(main_window.update_occupied_counters)
    model.dataChanged.connect(main_window.update_selection_count)
    main_window.update_occupied_counters()
    main_window.update_selection_count()
    main_window.mark_change()

def fill_random_cat(main_window):
    col = main_window.table.currentIndex().column()
    if col < 0:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("random", "Selecciona una columna primero."))
        return
    dlg = CatDialog(main_window)
    if dlg.exec() != QDialog.DialogCode.Accepted:
        return
    cats = dlg.cat_edit.text()
    try:
        n_rows = int(dlg.n_rows.text())
    except ValueError:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("random", "Ingresa un número válido de filas."))
        return
    cat_list = [c.strip() for c in cats.split(",") if c.strip()]
    if not cat_list:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("random", "Ingresa al menos una categoría."))
        return
    model = main_window.table.model()
    while model.rowCount() < n_rows:
        model.insertRow(model.rowCount())
    try:
        model.dataChanged.disconnect(main_window.update_occupied_counters)
        model.dataChanged.disconnect(main_window.update_selection_count)
    except Exception:
        pass
    for row in range(n_rows):
        model._df.iat[row, col] = random.choice(cat_list)
    main_window.table.viewport().update()
    model.dataChanged.connect(main_window.update_occupied_counters)
    model.dataChanged.connect(main_window.update_selection_count)
    main_window.update_occupied_counters()
    main_window.update_selection_count()
    main_window.mark_change()

_plugin_translator = None

def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator

load_plugin_translator()