import numpy as np
import pandas as pd
import os
import matplotlib.pyplot as plt
import statsmodels.api as sm
import scipy.stats as stats
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from PyQt6.QtWidgets import QDateEdit, QSpinBox, QProgressBar, QApplication, QLineEdit, QGridLayout, QMessageBox, QDialog, QVBoxLayout, QDialogButtonBox, QLabel, QListWidget, QPushButton, QHBoxLayout, QFrame, QCheckBox, QComboBox
from PyQt6.QtGui import QAction, QIcon, QIntValidator
from PyQt6.QtCore import Qt, QSize, QTimer, QCoreApplication, QSettings, QTranslator
from draggable_list_widget import DraggableListWidget
from utils import resource_path
from statsmodels.stats.stattools import durbin_watson
from data_model import PandasModel
from scipy.stats import boxcox
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.stats.diagnostic import acorr_ljungbox, het_arch
import warnings

__name__ = "Series de tiempo"
__version__ = "1.0.0"
__author__ = "Erick Victor Araujo Rivasplata"
__description__ = "Análisis de series de tiempo con metodología Box-Jenkins."

def get_plugin_name():
    return QCoreApplication.translate("MainWindow", "Series de tiempo")
def get_plugin_description():
    return QCoreApplication.translate("MainWindow", "Análisis de series de tiempo con metodología Box-Jenkins.")
def tabla_html_style():
    return (
        "border-collapse: collapse; width: auto; font-family: Arial, sans-serif; font-size: 12px; margin-top: 10px; margin-bottom: 5px; border-radius: 10px; border: 1px solid grey; overflow: hidden;"
    )
def th_style():
    return (
        "border: 1px solid grey; padding: 5px; background-color: #f2f2f2; text-align: center; vertical-align: middle;"
    )
def td_style():
    return (
        "border: 1px solid grey; padding: 5px; text-align: center;"
    )
def safe_float(val):
    try:
        return float(val)
    except Exception:
        return float('nan')
    
def register_plugin(main_window):
    box_menu = main_window.menuBar().addMenu(QCoreApplication.translate("MainWindow", "Series de Tiempo"))
    box_menu.setObjectName("plugin_menu_box_jenkins")
    gen_dates_action = QAction(QCoreApplication.translate("MainWindow", "Generar fechas"), main_window)
    gen_dates_action.triggered.connect(lambda: show_generate_date_column(main_window))
    box_menu.addAction(gen_dates_action)
    ident_action = QAction(QCoreApplication.translate("MainWindow", "Identificación"), main_window)
    ident_action.triggered.connect(lambda: show_bj_identification(main_window))
    box_menu.addAction(ident_action)
    est_action = QAction(QCoreApplication.translate("MainWindow", "Estimación"), main_window)
    est_action.triggered.connect(lambda: show_bj_estimation(main_window))
    box_menu.addAction(est_action)
    diag_action = QAction(QCoreApplication.translate("MainWindow", "Diagnóstico"), main_window)
    diag_action.triggered.connect(lambda: show_bj_diagnosis(main_window))
    box_menu.addAction(diag_action)
    forecast_action = QAction(QCoreApplication.translate("MainWindow", "Pronóstico"), main_window)
    forecast_action.triggered.connect(lambda: show_bj_forecast(main_window))
    box_menu.addAction(forecast_action)
    preproc_action = QAction(QCoreApplication.translate("MainWindow", "Pre-procesar"), main_window)
    preproc_action.triggered.connect(lambda: show_bj_preprocessing(main_window))
    box_menu.addAction(preproc_action)

def safe_exec(func):
    def wrapper(*args, **kwargs):
        main_window = args[0] if args else None
        try:
            return func(*args, **kwargs)
        except Exception as e:
            import traceback
            error_msg = traceback.format_exc()
            QMessageBox.warning(
                main_window,
                "EVAR Stat",
                QCoreApplication.translate(
                    "MainWindow",
                    "Asegúrate de haber realizado el análisis correctamente, vuelve a intentarlo:\n\n{error}\n\nDetalles:\n{trace}"
                ).format(error=str(e), trace=error_msg)
            )
            return None
    return wrapper

def frecuencia_amigable(codigo):
    norm = normalize_freq_code(codigo)
    if norm is None:
        return str(codigo)
    mapa = {
         "YS": "Anual",
         "4MS": "Cuatrimestral",
         "QS": "Trimestral",
         "MS": "Mensual",
         "W-MON": "Semanal",
         "D": "Diaria"
    }
    return mapa.get(str(norm).upper(), str(codigo))

def normalize_freq_code(code):
    if code is None:
        return None
    s = str(code).upper()
    s = s.split('-')[0]
    if s in ("A", "Y", "AS"):
        return "YS"
    if s.startswith("Q"):
        return "QS"
    if s in ("M", "MONTH", "MS"):
        return "MS"
    if s.startswith("W"):
        return "W-MON"
    if s in ("D", "DAILY"):
        return "D"
    return s

def show_detected_freq_dialog(main_window, detected_freq, n_obs=None):
    dialog = QDialog(main_window)
    dialog.setWindowModality(Qt.WindowModality.WindowModal)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Identificación de la serie"))
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    freq_label = QLabel(QCoreApplication.translate(
        "MainWindow",
        "Frecuencia de la serie:"
    ))
    layout.addWidget(freq_label)
    freq_cb = QComboBox()
    freq_cb.setFixedHeight(40)
    freq_options = [
        (QCoreApplication.translate("MainWindow", "Diaria"), "D"),
        (QCoreApplication.translate("MainWindow", "Semanal"), "W-MON"),
        (QCoreApplication.translate("MainWindow", "Mensual"), "MS"),
        (QCoreApplication.translate("MainWindow", "Trimestral"), "QS"),
        (QCoreApplication.translate("MainWindow", "Cuatrimestral"), "4MS"),
        (QCoreApplication.translate("MainWindow", "Anual"), "YS"),
    ]
    det_norm = normalize_freq_code(detected_freq) if detected_freq is not None else None
    standard_norms = [normalize_freq_code(rule) for _, rule in freq_options]
    if det_norm and det_norm not in standard_norms:
        freq_options.insert(0, (frecuencia_amigable(detected_freq), detected_freq))
    for label, rule in freq_options:
        freq_cb.addItem(label, userData=rule)
    if det_norm:
        for i in range(freq_cb.count()):
            item_data = freq_cb.itemData(i)
            if normalize_freq_code(item_data) == det_norm:
                freq_cb.setCurrentIndex(i)
                break
    layout.addWidget(freq_cb)
    layout.addSpacing(8)
    lags_label = QLabel(QCoreApplication.translate("MainWindow", "Rezagos para ACF/PACF:"))
    layout.addWidget(lags_label)
    lags_spin = QSpinBox()
    lags_spin.setMinimum(1)
    if n_obs is not None and n_obs > 1:
        allowed_max = max(1, (n_obs - 1) // 2)
        lags_spin.setMaximum(allowed_max)
        lags_spin.setValue(min(40, allowed_max))
    else:
        lags_spin.setMaximum(100)
        lags_spin.setValue(40)
    lags_spin.setFixedHeight(40)
    layout.addWidget(lags_spin)
    btns = QHBoxLayout()
    ok = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok.setStyleSheet("font-size: 12px; height: 18px;")
    cancel.setStyleSheet("font-size: 12px; height: 18px;")
    btns.addStretch(1); btns.addWidget(ok); btns.addSpacing(8); btns.addWidget(cancel); btns.addStretch(1)
    layout.addSpacing(8); layout.addLayout(btns)
    ok.clicked.connect(dialog.accept)
    cancel.clicked.connect(dialog.reject)
    if dialog.exec() == QDialog.DialogCode.Accepted:
        return freq_cb.currentData(), lags_spin.value()
    return None, None

@safe_exec
def show_bj_identification(main_window):
    tiempo_col_name, serie_col_name = show_ts_column_selection_dialog(main_window, QCoreApplication.translate("MainWindow", "Identificación Box-Jenkins"))
    if not serie_col_name:
        return
    tiempo_col, serie_col, model = None, None, main_window.table.model()
    for col in range(model.columnCount()):
        header = model.headerData(col, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
        if header:
            if header == serie_col_name: serie_col = col
            if tiempo_col_name and header == tiempo_col_name: tiempo_col = col
    data, tiempos = [], []
    for row in range(model.rowCount()):
        item = model.data(model.index(row, serie_col), Qt.ItemDataRole.DisplayRole)
        if item is not None and str(item).strip() != "":
            try:
                data.append(float(item))
                if tiempo_col is not None:
                    tiempo_item = model.data(model.index(row, tiempo_col), Qt.ItemDataRole.DisplayRole)
                    tiempos.append(str(tiempo_item) if tiempo_item is not None else "")
            except Exception: pass
    if len(data) < 10:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "La serie debe tener al menos 10 datos numéricos."))
        return
    if tiempo_col is not None and len(tiempos) == len(data):
        fechas = pd.to_datetime(tiempos, errors='coerce')
        serie = pd.Series(data, index=fechas).dropna()
    else:
        serie = pd.Series(data)
    if isinstance(serie.index, pd.DatetimeIndex):
        detected_freq = serie.index.inferred_freq
        n_obs_temp = len(serie.dropna())
        freq_rule, num_lags = show_detected_freq_dialog(main_window, detected_freq, n_obs=n_obs_temp)
        if freq_rule is None or num_lags is None:
            return
        if freq_rule and normalize_freq_code(freq_rule) != normalize_freq_code(detected_freq):
            try:
                serie = serie.asfreq(freq_rule)
            except Exception as e:
                QMessageBox.warning(
                    main_window,
                    "EVAR Stat",
                    QCoreApplication.translate(
                        "MainWindow",
                        "No se pudo cambiar la frecuencia: {error}"
                    ).format(error=e)
                )
                return
    else:
        detected_freq = None
        num_lags = 40  
    n_obs = len(serie.dropna())
    max_allowed = max(1, (n_obs - 1) // 2)
    if num_lags > max_allowed:
        num_lags = max_allowed
    plt.figure(figsize=(8,3))
    serie.plot(title=QCoreApplication.translate("MainWindow", "Serie {serie}").format(serie=serie_col_name))
    plt.tight_layout()
    plt.show()
    adf = adfuller(serie.dropna())
    kpss_stat, kpss_p, _, kpss_crit = kpss(serie.dropna(), regression='c', nlags="auto")
    adf_html = f"""
    <span style="font-weight:bold;">{QCoreApplication.translate("MainWindow", "Pruebas de estacionariedad")}</span>
    <table style='{tabla_html_style()}'>
        <tr>
            <th colspan="5" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Dickey-Fuller aumentada (ADF)")}</th>
        </tr>
        <tr>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Estadístico")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 1%")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 5%")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 10%")}</th>
        </tr>
        <tr>
            <td style='{td_style()}'>{adf[0]:.4f}</td>
            <td style='{td_style()}'>{adf[1]:.4f}</td>
            <td style='{td_style()}'>{adf[4]['1%']:.4f}</td>
            <td style='{td_style()}'>{adf[4]['5%']:.4f}</td>
            <td style='{td_style()}'>{adf[4]['10%']:.4f}</td>
        </tr>
    </table>
    """
    main_window.result_area.append(adf_html)
    kpss_html = f"""
    <table style='{tabla_html_style()}'>
        <tr>
            <th colspan="5" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "KPSS (Kwiatkowski–Phillips–Schmidt–Shin)")}</th>
        </tr>
        <tr>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Estadístico")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 1%")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 5%")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Valor crítico 10%")}</th>
        </tr>
        <tr>
            <td style='{td_style()}'>{kpss_stat:.4f}</td>
            <td style='{td_style()}'>{kpss_p:.4f}</td>
            <td style='{td_style()}'>{kpss_crit['1%']:.4f}</td>
            <td style='{td_style()}'>{kpss_crit['5%']:.4f}</td>
            <td style='{td_style()}'>{kpss_crit['10%']:.4f}</td>
        </tr>
    </table>
    <p style='margin-bottom: 200px;'></p>
    """
    main_window.result_area.append(kpss_html)
    QTimer.singleShot(0, main_window.scroll_result_area_to_end)
    try:
        fig, ax = plt.subplots(figsize=(8, 3))
        plot_acf(
            serie.dropna(),
            lags=num_lags,
            ax=ax,
            title=QCoreApplication.translate("MainWindow", "ACF de la serie {serie}").format(serie=serie_col_name)
        )
        ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))
        plt.tight_layout()
        plt.show()
    except Exception as e:
        QMessageBox.warning(
            main_window,
            "EVAR Stat",
            QCoreApplication.translate("MainWindow", "No se pudo graficar ACF: {error}").format(error=e)
        )
    try:
        fig, ax = plt.subplots(figsize=(8, 3))
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=UserWarning)
            plot_pacf(
                serie.dropna(),
                lags=num_lags,
                ax=ax,
                title=QCoreApplication.translate("MainWindow", "PACF de la serie {serie}").format(serie=serie_col_name),
                method="ywm"
            )
        ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))
        plt.tight_layout()
        plt.show()
    except Exception as e:
        QMessageBox.warning(
            main_window,
            "EVAR Stat",
            QCoreApplication.translate("MainWindow", "No se pudo graficar PACF: {error}").format(error=e)
        )
    try:
        sugerido = 12
        if serie.index.inferred_freq:
            freq = serie.index.inferred_freq.lower()
            if "a" in freq:
                sugerido = None
            elif "q" in freq:
                sugerido = 4
            elif "m" in freq:
                sugerido = 12
            elif "w" in freq:
                sugerido = 52
            elif "d" in freq:
                sugerido = 7
        else:
            sugerido = 12
        if sugerido is not None and int(sugerido) > 1:
            decomposition = sm.tsa.seasonal_decompose(serie.dropna(), model='additive', period=int(sugerido))
            fig = decomposition.plot()
            fig.set_size_inches(8, 6)
            plt.suptitle(QCoreApplication.translate("MainWindow", "Descomposición aditiva de la serie {serie}").format(serie=serie_col_name), fontsize=14)
            plt.tight_layout()
            plt.show()
    except Exception as e:
        QMessageBox.warning(
            main_window,
            "EVAR Stat",
            QCoreApplication.translate('MainWindow', 'No se pudo calcular la descomposición: {error}').format(error=e)
        )

def show_auto_model_progress(main_window, serie, is_anual, prefill_s):
    progress_dialog = QDialog(main_window)
    progress_dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Modelo automático"))
    vlayout = QVBoxLayout(progress_dialog)
    vlayout.setContentsMargins(20, 20, 20, 20)
    vlayout.setSpacing(10)
    label = QLabel(QCoreApplication.translate("MainWindow", "Creando el mejor modelo ARIMA/SARIMA .."))
    vlayout.addWidget(label)
    progress_bar = QProgressBar()
    progress_bar.setMinimum(0)
    progress_bar.setMaximum(100)
    progress_bar.setValue(0)
    progress_bar.setTextVisible(True)
    progress_bar.setFixedHeight(35)
    progress_bar.setStyleSheet("""
        QProgressBar {
            border: 2px solid #2B90B9;
            border-radius: 8px;
            background-color: #f2f2f2;
            font: bold 12px 'Segoe UI', Arial, sans-serif;
            color: #333;
            padding: 2px;
            text-align: center;
        }
        QProgressBar::chunk {
            background-color: qlineargradient(
                spread:pad, x1:0, y1:0, x2:1, y2:0,
                stop:0 #2B90B9, stop:1 #6DD5FA
            );
            border-radius: 8px;
        }
    """)
    vlayout.addWidget(progress_bar)
    vlayout.addSpacing(10)
    progress_dialog.setModal(True)
    progress_dialog.show()
    QApplication.processEvents()
    warnings.filterwarnings("ignore")
    p_range = range(0, 4)
    d_range = range(0, 2)
    q_range = range(0, 4)
    P_range = range(0, 2)
    D_range = range(0, 2)
    Q_range = range(0, 2)
    try:
        s_value = int(prefill_s) if (prefill_s is not None and int(prefill_s) > 1) else None
    except Exception:
        s_value = None
    try:
        nobs = len(serie.dropna())
    except Exception:
        nobs = None
    if s_value is not None:
        if (nobs is not None and s_value >= nobs) or s_value <= 1:
            s_value = None
        else:
            try:
                if nobs is not None and s_value > max(1, nobs // 2):
                    s_value = None
            except Exception:
                pass
    if is_anual or s_value is None:
        total = len(p_range) * len(d_range) * len(q_range)
    else:
        total = len(p_range) * len(d_range) * len(q_range) * len(P_range) * len(D_range) * len(Q_range)
    progress_bar.setMaximum(total)
    progress_bar.setValue(0)
    progress_dialog.repaint()
    best_aic = float("inf")
    best_order = None
    best_seasonal_order = None
    best_result = None
    count = 0
    for p in p_range:
        for d in d_range:
            for q in q_range:
                if is_anual or s_value is None:
                    try:
                        model = sm.tsa.ARIMA(serie, order=(p, d, q))
                        result = model.fit()
                        if result.aic < best_aic:
                            best_aic = result.aic
                            best_order = (p, d, q)
                            best_seasonal_order = None
                            best_result = result
                    except Exception:
                        pass
                    count += 1
                    progress_bar.setValue(count)
                    QApplication.processEvents()
                else:
                    for P in P_range:
                        for D in D_range:
                            for Q in Q_range:
                                try:
                                    model = sm.tsa.SARIMAX(
                                        serie,
                                        order=(p, d, q),
                                        seasonal_order=(P, D, Q, s_value),
                                        enforce_stationarity=False,
                                        enforce_invertibility=False
                                    )
                                    result = model.fit(disp=False)
                                    if result.aic < best_aic:
                                        best_aic = result.aic
                                        best_order = (p, d, q)
                                        best_seasonal_order = (P, D, Q, s_value)
                                        best_result = result
                                except Exception:
                                    pass
                                count += 1
                                progress_bar.setValue(count)
                                QApplication.processEvents()
    progress_dialog.close()
    if best_result is None:
        QMessageBox.warning(
            main_window,
            "EVAR Stat",
            QCoreApplication.translate(
                "MainWindow",
                "No se pudo ajustar ningún modelo automáticamente."
            )
        )
        return None, None, None
    if best_seasonal_order:
        P, D, Q, s = best_seasonal_order
        modelo_str = f"SARIMA ({best_order[0]}, {best_order[1]}, {best_order[2]}) x ({P}, {D}, {Q}){s}"
        params_dict = dict(order=best_order, seasonal_order=best_seasonal_order)
    else:
        modelo_str = f"ARIMA ({best_order[0]}, {best_order[1]}, {best_order[2]})"
        params_dict = dict(order=best_order)
    return best_result, params_dict, modelo_str
@safe_exec
def show_bj_estimation(main_window):
    tiempo_col_name, serie_col_name = show_ts_column_selection_dialog(main_window, QCoreApplication.translate("MainWindow", "Estimación Box-Jenkins"))
    if not serie_col_name:
        return
    tiempo_col, serie_col, model = None, None, main_window.table.model()
    for col in range(model.columnCount()):
        header = model.headerData(col, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
        if header:
            if header == serie_col_name: serie_col = col
            if tiempo_col_name and header == tiempo_col_name: tiempo_col = col
    data, tiempos = [], []
    for row in range(model.rowCount()):
        item = model.data(model.index(row, serie_col), Qt.ItemDataRole.DisplayRole)
        if item is not None and str(item).strip() != "":
            try:
                data.append(float(item))
                if tiempo_col is not None:
                    tiempo_item = model.data(model.index(row, tiempo_col), Qt.ItemDataRole.DisplayRole)
                    tiempos.append(str(tiempo_item) if tiempo_item is not None else "")
            except Exception: pass
    if len(data) < 10:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "La serie debe tener al menos 10 datos numéricos."))
        return
    if tiempo_col is not None and len(tiempos) == len(data):
        fechas = pd.to_datetime(tiempos, errors='coerce')
        serie = pd.Series(data, index=fechas).dropna()
    else:
        serie = pd.Series(data)
    dialog = QDialog(main_window)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Parámetros del modelo ARIMA/SARIMA"))
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    freq_rule = None
    prefill_s = None
    is_anual = False
    freq_cb = None
    s_edit = None
    table_layout = QGridLayout()
    table_layout.setSpacing(5)
    table_layout.addWidget(QLabel(""), 0, 0)
    table_layout.addWidget(QLabel("No estacional"), 0, 1)
    table_layout.addWidget(QLabel("  Estacional"), 0, 2)
    table_layout.addWidget(QLabel(QCoreApplication.translate("MainWindow", "Autorregresivo:")), 1, 0)
    p_edit = QLineEdit(); p_edit.setFixedWidth(80); p_edit.setFixedHeight(40); p_edit.setValidator(QIntValidator(0, 99))
    p_edit.setPlaceholderText("p"); p_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(p_edit, 1, 1)
    P_edit = QLineEdit(); P_edit.setFixedWidth(80); P_edit.setFixedHeight(40); P_edit.setValidator(QIntValidator(0, 99))
    P_edit.setPlaceholderText("P"); P_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(P_edit, 1, 2)
    table_layout.addWidget(QLabel(QCoreApplication.translate("MainWindow", "Diferencia:")), 2, 0)
    d_edit = QLineEdit(); d_edit.setFixedWidth(80); d_edit.setFixedHeight(40); d_edit.setValidator(QIntValidator(0, 2))
    d_edit.setPlaceholderText("d"); d_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(d_edit, 2, 1)
    D_edit = QLineEdit(); D_edit.setFixedWidth(80); D_edit.setFixedHeight(40); D_edit.setValidator(QIntValidator(0, 2))
    D_edit.setPlaceholderText("D"); D_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(D_edit, 2, 2)
    table_layout.addWidget(QLabel(QCoreApplication.translate("MainWindow", "Media móvil:")), 3, 0)
    q_edit = QLineEdit(); q_edit.setFixedWidth(80); q_edit.setFixedHeight(40); q_edit.setValidator(QIntValidator(0, 99))
    q_edit.setPlaceholderText("q"); q_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(q_edit, 3, 1)
    Q_edit = QLineEdit(); Q_edit.setFixedWidth(80); Q_edit.setFixedHeight(40); Q_edit.setValidator(QIntValidator(0, 99))
    Q_edit.setPlaceholderText("Q"); Q_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    table_layout.addWidget(Q_edit, 3, 2)
    table_layout.addWidget(QLabel(QCoreApplication.translate("MainWindow", "Período (s):")), 4, 0)
    s_edit = QLineEdit(); s_edit.setAlignment(Qt.AlignmentFlag.AlignCenter)
    s_edit.setFixedWidth(80)
    s_edit.setFixedHeight(40)
    s_edit.setValidator(QIntValidator(1, 99))
    if prefill_s is not None:
        s_edit.setText(str(prefill_s))
    table_layout.addWidget(QLabel(""), 4, 1)
    table_layout.addWidget(s_edit, 4, 2)
    if isinstance(serie.index, pd.DatetimeIndex):
        detected_freq = serie.index.inferred_freq
        freq_row_layout = QHBoxLayout()
        freq_label = QLabel(QCoreApplication.translate("MainWindow", "Frecuencia de la serie:"))
        freq_cb = QComboBox()
        freq_cb.setFixedHeight(40)
        freq_options = [
            (QCoreApplication.translate("MainWindow", "Diaria"), "D"),
            (QCoreApplication.translate("MainWindow", "Semanal"), "W-MON"),
            (QCoreApplication.translate("MainWindow", "Mensual"), "MS"),
            (QCoreApplication.translate("MainWindow", "Trimestral"), "QS"),
            (QCoreApplication.translate("MainWindow", "Cuatrimestral"), "4MS"),
            (QCoreApplication.translate("MainWindow", "Anual"), "YS"),
        ]
        det_norm = normalize_freq_code(detected_freq) if detected_freq is not None else None
        standard_norms = [normalize_freq_code(rule) for _, rule in freq_options]
        if det_norm and det_norm not in standard_norms:
            freq_options.insert(0, (frecuencia_amigable(detected_freq), detected_freq))
        for label, rule in freq_options:
            freq_cb.addItem(label, userData=rule)
        if det_norm:
            for i in range(freq_cb.count()):
                item_data = freq_cb.itemData(i)
                if normalize_freq_code(item_data) == det_norm:
                    freq_cb.setCurrentIndex(i)
                    break
        freq_row_layout.addWidget(freq_label)
        freq_row_layout.addWidget(freq_cb)
        layout.addLayout(freq_row_layout)
        layout.addSpacing(8)
        def update_freq():
            nonlocal serie, freq_rule, prefill_s, is_anual
            freq_rule = freq_cb.currentData()
            if freq_rule and normalize_freq_code(freq_rule) != normalize_freq_code(detected_freq):
                try:
                    serie = serie.asfreq(freq_rule)
                except Exception as e:
                    QMessageBox.warning(
                        main_window,
                        "EVAR Stat",
                        QCoreApplication.translate(
                            "MainWindow",
                            "No se pudo cambiar la frecuencia: {error}"
                        ).format(error=e)
                    )
                    return
            rule_norm = normalize_freq_code(serie.index.inferred_freq if serie.index.inferred_freq is not None else freq_rule)
            if rule_norm == "YS":
                prefill_s = None
                is_anual = True
                s_edit.setDisabled(True)
                s_edit.clear()
            elif rule_norm == "QS":
                prefill_s = 4
                is_anual = False
                s_edit.setDisabled(False)
                s_edit.setValidator(QIntValidator(2, 99))
            elif rule_norm == "4MS":
                prefill_s = 3
                is_anual = False
                s_edit.setDisabled(False)
                s_edit.setValidator(QIntValidator(2, 99))
            elif rule_norm == "MS":
                prefill_s = 12
                is_anual = False
                s_edit.setDisabled(False)
                s_edit.setValidator(QIntValidator(2, 99))
            elif rule_norm == "W-MON":
                prefill_s = 52
                is_anual = False
                s_edit.setDisabled(False)
                s_edit.setValidator(QIntValidator(2, 99))
            elif rule_norm == "D":
                prefill_s = 7
                is_anual = False
                s_edit.setDisabled(False)
                s_edit.setValidator(QIntValidator(2, 99))

            if prefill_s is not None:
                 s_edit.setText(str(prefill_s))
            else:
                 s_edit.setText("")
        freq_cb.currentIndexChanged.connect(update_freq)
        update_freq()  
    layout.addLayout(table_layout)
    layout.addSpacing(8)
    auto_params_checkbox = QCheckBox(QCoreApplication.translate(
        "MainWindow",
        "Generar modelo (Mejores parámetros)"
    ))
    auto_params_checkbox.setChecked(False)
    layout.addWidget(auto_params_checkbox)
    progress_bar = QProgressBar()
    progress_bar.setMinimum(0)
    progress_bar.setMaximum(100)
    progress_bar.setValue(0)
    progress_bar.setVisible(False)
    progress_bar.setTextVisible(True)
    progress_bar.setFixedHeight(35)
    progress_bar.setStyleSheet("""
        QProgressBar {
            border: 2px solid #2B90B9;
            border-radius: 8px;
            background-color: #f2f2f2;
            font: bold 12px 'Segoe UI', Arial, sans-serif;
            color: #333;
            padding: 2px;
            text-align: center;
        }
        QProgressBar::chunk {
            background-color: qlineargradient(
                spread:pad, x1:0, y1:0, x2:1, y2:0,
                stop:0 #2B90B9, stop:1 #6DD5FA
            );
            border-radius: 8px;
        }
    """)
    layout.addWidget(progress_bar)
    buttons_layout = QHBoxLayout()
    ok_button = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel_button = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok_button.setStyleSheet("font-size: 12px; height: 18px;")
    cancel_button.setStyleSheet("font-size: 12px; height: 18px;")
    buttons_layout.addStretch(1)
    buttons_layout.addWidget(ok_button)
    buttons_layout.addSpacing(25)
    buttons_layout.addWidget(cancel_button)
    buttons_layout.addStretch(1)
    layout.addLayout(buttons_layout)
    dialog.setLayout(layout)
    accepted = [False]
    def on_accept():
        if freq_cb:
            update_freq()
        accepted[0] = True
        dialog.accept()
    ok_button.clicked.connect(on_accept)
    cancel_button.clicked.connect(dialog.reject)
    if not dialog.exec() or not accepted[0]:
        return
    if auto_params_checkbox.isChecked():
        result, params_dict, modelo_str = show_auto_model_progress(main_window, serie, is_anual, prefill_s)
        if result is None:
            return
    else:
        try:
            p = int(p_edit.text())
            d = int(d_edit.text())
            q = int(q_edit.text())
            P = P_edit.text()
            D = D_edit.text()
            Q = Q_edit.text()
            s = s_edit.text()
            if P == "" and D == "" and Q == "" and s == "":
                model = sm.tsa.ARIMA(serie, order=(p, d, q))
                result = model.fit()
                modelo_str = f"ARIMA ({p}, {d}, {q})"
                params_dict = dict(order=(p, d, q))
            else:
                if s is None or s.strip() == "":
                    QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Debe ingresar el período estacional (s) para SARIMA."))
                    return
                try:
                    s_int = int(s)
                except Exception:
                    QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Período estacional inválido. Debe ser un número entero mayor a 1."))
                    return
                if s_int <= 1:
                    QMessageBox.warning(
                        main_window,
                        "EVAR Stat",
                        QCoreApplication.translate(
                            "MainWindow",
                            "El período estacional debe ser mayor a 1 para SARIMA.\nSi tu serie es anual, usa ARIMA (campos estacionales vacíos)."
                        )
                    )
                    return
                try:
                    nobs = len(serie.dropna())
                except Exception:
                    nobs = None
                if nobs is not None and s_int >= nobs:
                    QMessageBox.warning(
                        main_window,
                        "EVAR Stat",
                        QCoreApplication.translate(
                            "MainWindow",
                            "El período estacional (s) debe ser menor al número de observaciones."
                        )
                    )
                    return
                try:
                    P_i, D_i, Q_i = int(P), int(D), int(Q)
                except Exception:
                    QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Los parámetros estacionales P, D y Q deben ser enteros."))
                    return
                model = sm.tsa.SARIMAX(
                    serie,
                    order=(p, d, q),
                    seasonal_order=(P_i, D_i, Q_i, s_int),
                    enforce_stationarity=False,
                    enforce_invertibility=False
                )
                result = model.fit(disp=False)
                modelo_str = f"SARIMA ({p}, {d}, {q}) x ({P_i}, {D_i}, {Q_i}){s_int}"
                params_dict = dict(order=(p, d, q), seasonal_order=(P_i, D_i, Q_i, s_int))
        except Exception as e:
            QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Asegúrate de haber ingresado los parámetros correctamente.\nError: {error}").format(error=e))
            return
    main_window.last_arima_result = result
    main_window.last_arima_params = params_dict
    main_window.last_arima_cols = (tiempo_col_name, serie_col_name)
    params = result.params
    bse = result.bse
    zvalues = result.tvalues
    pvalues = result.pvalues
    conf_int = result.conf_int()
    coef_html = f"""
    <span style="font-weight:bold;">{QCoreApplication.translate("MainWindow", "Modelo")} {modelo_str}</span>
    <table style='{tabla_html_style()}'>
        <tr>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Parámetro")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Coeficiente")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Error estándar")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Z")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "IC al 95%")}</th>
        </tr>
        {''.join(
            f"<tr><td style='{td_style()}'>{param}</td>"
            f"<td style='{td_style()}'>{params[param]:.4f}</td>"
            f"<td style='{td_style()}'>{bse[param]:.4f}</td>"
            f"<td style='{td_style()}'>{zvalues[param]:.2f}</td>"
            f"<td style='{td_style()}'>{pvalues[param]:.4f}</td>"
            f"<td style='{td_style()}'>[{conf_int.loc[param,0]:.4f}, {conf_int.loc[param,1]:.4f}]</td></tr>"
            for param in params.index
        )}
    </table>
    """
    main_window.result_area.append(coef_html)
    info_html = f"""
    <table style='{tabla_html_style()}'>
        <tr>
            <th colspan="4" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Criterios de información")}</th>
        </tr>
        <tr>
            <th style='{th_style()}'>AIC</th>
            <th style='{th_style()}'>BIC</th>
            <th style='{th_style()}'>HQIC</th>
            <th style='{th_style()}'>LogLik</th>
        </tr>
        <tr>
            <td style='{td_style()}'>{result.aic:.4f}</td>
            <td style='{td_style()}'>{result.bic:.4f}</td>
            <td style='{td_style()}'>{result.hqic:.4f}</td>
            <td style='{td_style()}'>{result.llf:.4f}</td>
        </tr>
    </table>
    <p style='margin-bottom: 200px;'></p>
    """
    main_window.result_area.append(info_html)
    QTimer.singleShot(0, main_window.scroll_result_area_to_end)

def show_lags_dialog(main_window, n_obs, default_lags=40):
    dialog = QDialog(main_window)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Número de rezagos"))
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    label = QLabel(QCoreApplication.translate("MainWindow", "Rezagos para el ACF/PACF:"))
    layout.addWidget(label)
    lags_spin = QSpinBox()
    allowed_max = max(1, (n_obs - 1) // 2)
    lags_spin.setMinimum(1)
    lags_spin.setMaximum(allowed_max)
    lags_spin.setValue(min(default_lags, allowed_max))
    lags_spin.setFixedHeight(40)
    layout.addWidget(lags_spin)
    btns = QHBoxLayout()
    ok = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok.setStyleSheet("font-size: 12px; height: 18px;")
    cancel.setStyleSheet("font-size: 12px; height: 18px;")
    btns.addStretch(1); btns.addWidget(ok); btns.addSpacing(8); btns.addWidget(cancel); btns.addStretch(1)
    layout.addSpacing(8); layout.addLayout(btns)
    ok.clicked.connect(dialog.accept)
    cancel.clicked.connect(dialog.reject)
    if dialog.exec() == QDialog.DialogCode.Accepted:
        return lags_spin.value()
    return None
@safe_exec
def show_bj_diagnosis(main_window):
    result = getattr(main_window, "last_arima_result", None)
    if result is None:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Primero debe estimar un modelo en la etapa 2."))
        return
    params = getattr(main_window, "last_arima_params", None)
    try:
        resid = result.resid
        n_obs = len(pd.Series(resid).dropna())
        num_lags = show_lags_dialog(main_window, n_obs)
        if num_lags is None:
            return
        max_allowed = max(1, (n_obs - 1) // 2)
        if num_lags > max_allowed:
            num_lags = max_allowed
        modelo_str = ""
        params = getattr(main_window, "last_arima_params", None)
        if params:
            if "order" in params and "seasonal_order" in params:
                modelo_str = f"SARIMA{params['order']} x {params['seasonal_order']}"
            elif "order" in params:
                modelo_str = f"ARIMA{params['order']}"
            else:
                modelo_str = str(params)
        plt.figure(figsize=(8,3))
        plt.plot(resid)
        plt.title(
            QCoreApplication.translate(
                "MainWindow",
                "Residuos del modelo {modelo}"
            ).format(modelo=modelo_str)
        )
        plt.tight_layout()
        plt.show()
        fig, ax = plt.subplots(figsize=(8,3))
        plot_acf(resid, lags=num_lags, ax=ax, title=QCoreApplication.translate("MainWindow", "ACF de los residuos"))
        ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))
        plt.tight_layout()
        plt.show()
        fig, ax = plt.subplots(figsize=(8,3))
        plot_pacf(resid, lags=num_lags, ax=ax, title=QCoreApplication.translate("MainWindow", "PACF de los residuos"))
        ax.xaxis.set_major_locator(plt.MaxNLocator(integer=True))
        plt.tight_layout()
        plt.show()
        if hasattr(result, "fittedvalues"):
            plt.figure(figsize=(6,4))
            plt.scatter(result.fittedvalues, resid, alpha=0.6)
            plt.axhline(0, color='grey', linestyle='--')
            plt.xlabel(QCoreApplication.translate("MainWindow", "Valores ajustados"))
            plt.ylabel(QCoreApplication.translate("MainWindow", "Residuos"))
            plt.title(QCoreApplication.translate("MainWindow", "Residuos vs valores ajustados"))
            plt.tight_layout()
            plt.show()
        dw_stat = durbin_watson(resid)
        y_true = result.data.endog if hasattr(result, "data") else None
        y_pred = result.fittedvalues if hasattr(result, "fittedvalues") else None
        if y_true is not None and y_pred is not None:
            mse = mean_squared_error(y_true, y_pred)
            rmse = mse**0.5
            mae = mean_absolute_error(y_true, y_pred)
            mape = (np.abs((y_true - y_pred) / y_true).mean()) * 100
            metrics_html = f"""
            <span style="font-weight:bold;">{QCoreApplication.translate("MainWindow", "Métricas de ajuste del modelo")} {modelo_str}</span>
            <table style='{tabla_html_style()}'>
                <tr>
                    <th style='{th_style()}'>Durbin-Watson</th>
                    <th style='{th_style()}'>MSE</th>
                    <th style='{th_style()}'>RMSE</th>
                    <th style='{th_style()}'>MAE</th>
                    <th style='{th_style()}'>MAPE (%)</th>
                </tr>
                <tr>
                    <td style='{td_style()}'>{dw_stat:.4f}</td>
                    <td style='{td_style()}'>{mse:.4f}</td>
                    <td style='{td_style()}'>{rmse:.4f}</td>
                    <td style='{td_style()}'>{mae:.4f}</td>
                    <td style='{td_style()}'>{mape:.2f}</td>
                </tr>
            </table>
            """
            main_window.result_area.append(metrics_html)
        resid_clean = np.asarray(resid)
        resid_clean = resid_clean[~np.isnan(resid_clean)]
        max_lag = min(10, max(1, len(resid_clean) // 2))
        lb_stat_val = float("nan")
        lb_p_val = float("nan")
        lb_df = max_lag
        if len(resid_clean) > 1 and max_lag >= 1:
            try:
                lb_test = acorr_ljungbox(resid_clean, lags=[max_lag], return_df=True)
                lb_stat_val = safe_float(lb_test['lb_stat'].values[0])
                lb_p_val = safe_float(lb_test['lb_pvalue'].values[0])
            except Exception:
                lb_stat_val = float("nan")
                lb_p_val = float("nan")
        lb_html = f"""
        <table style='{tabla_html_style()}'>
            <tr>
                <th colspan="3" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Prueba Ljung-Box (rezagos {lag})").format(lag=lb_df)}</th>
            </tr>
            <tr>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Estadístico")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "gl")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            </tr>
            <tr>
                <td style='{td_style()}'>{lb_stat_val:.4f}</td>
                <td style='{td_style()}'>{lb_df}</td>
                <td style='{td_style()}'>{lb_p_val:.4f}</td>
            </tr>
        </table>
        """
        main_window.result_area.append(lb_html)
        jb_stat, jb_p = stats.jarque_bera(resid)
        jb_df = 2  
        jb_html = f"""
        <table style='{tabla_html_style()}'>
            <tr>
                <th colspan="3" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Prueba de normalidad (Jarque-Bera)")}</th>
            </tr>
            <tr>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Estadístico")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "gl")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            </tr>
            <tr>
                <td style='{td_style()}'>{safe_float(jb_stat):.4f}</td>
                <td style='{td_style()}'>{jb_df}</td>
                <td style='{td_style()}'>{safe_float(jb_p):.4f}</td>
            </tr>
        </table>
        """
        main_window.result_area.append(jb_html)
        arch_stat, arch_p, arch_lags, _ = het_arch(resid)
        arch_df = arch_lags  
        arch_html = f"""
        <table style='{tabla_html_style()}'>
            <tr>
                <th colspan="3" style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Prueba de heterocedasticidad")}</th>
            </tr>
            <tr>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Estadístico")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "gl")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "p")}</th>
            </tr>
            <tr>
                <td style='{td_style()}'>{safe_float(arch_stat):.4f}</td>
                <td style='{td_style()}'>{"-" if (arch_df is None or np.isnan(safe_float(arch_df))) else f"{safe_float(arch_df):.4f}"}</td>
                <td style='{td_style()}'>{safe_float(arch_p):.4f}</td>
            </tr>
        </table>
        <p style='margin-bottom: 200px;'></p>
        """
        main_window.result_area.append(arch_html)
        QTimer.singleShot(0, main_window.scroll_result_area_to_end)
        model = main_window.table.model()
        df = model._df.copy()
        col_name = QCoreApplication.translate("MainWindow", "Residuos")
        base_col_name = col_name
        suffix = 1
        while col_name in df.columns:
            col_name = f"{base_col_name}_{suffix}"
            suffix += 1
        df[col_name] = ""
        resid_values = np.asarray(resid)
        for i in range(min(len(df), len(resid_values))):
            df.at[i, col_name] = resid_values[i]
        model_new = PandasModel(df, parent=main_window.table)
        main_window.table.setModel(model_new)
        if hasattr(main_window, "update_occupied_counters"):
            model_new.dataChanged.connect(main_window.update_occupied_counters)
        if hasattr(main_window, "update_selection_count"):
            model_new.dataChanged.connect(main_window.update_selection_count)
            if main_window.table.selectionModel():
                main_window.table.selectionModel().selectionChanged.connect(main_window.update_selection_count)
            main_window.update_selection_count()
        if hasattr(main_window, "update_occupied_counters"):
            main_window.update_occupied_counters()
    except Exception as e:
        QMessageBox.warning(
            main_window,
            "EVAR Stat",
            QCoreApplication.translate(
                "MainWindow",
                "No se pudo calcular el diagnóstico de residuos: {error}"
            ).format(error=e)
        )

def show_forecast_steps_dialog(main_window, default_value=3, min_value=1, max_value=120):
    dialog = QDialog(main_window)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Número de pronósticos"))
    dialog.setWindowModality(Qt.WindowModality.WindowModal)
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    pron_row = QHBoxLayout()
    label = QLabel(QCoreApplication.translate("MainWindow", "Número de pronósticos:"))
    spin = QSpinBox()
    spin.setMinimum(min_value)
    spin.setMaximum(max_value)
    spin.setValue(default_value)
    spin.setFixedHeight(40)
    pron_row.addWidget(label)
    pron_row.addWidget(spin)
    layout.addLayout(pron_row)
    layout.addSpacing(8)
    conf_row = QHBoxLayout()
    conf_lbl = QLabel(QCoreApplication.translate("MainWindow", "Nivel de confianza:"))
    conf_spin = QSpinBox()
    conf_spin.setMinimum(1)
    conf_spin.setMaximum(99)
    conf_spin.setValue(95) 
    conf_spin.setSuffix("%")
    conf_spin.setFixedHeight(40)
    conf_row.addWidget(conf_lbl)
    conf_spin.setSingleStep(1)
    conf_row.addWidget(conf_spin)
    layout.addLayout(conf_row)
    layout.addSpacing(8)
    mode_row = QHBoxLayout()
    mode_lbl = QLabel(QCoreApplication.translate("MainWindow", "Modo de gráficar:"))
    mode_cb = QComboBox()
    mode_cb.setFixedHeight(40)
    mode_cb.addItem(QCoreApplication.translate("MainWindow", "Serie + Pronóstico"), userData="orig_cont")
    mode_cb.addItem(QCoreApplication.translate("MainWindow", "Serie + Ajustada"), userData="orig_fit_pred")
    mode_cb.addItem(QCoreApplication.translate("MainWindow", "Solo pronósticos"), userData="only_pred")
    mode_cb.setCurrentIndex(0)
    mode_row.addWidget(mode_lbl)
    mode_row.addWidget(mode_cb)
    layout.addLayout(mode_row)
    layout.addSpacing(8)
    buttons_layout = QHBoxLayout()
    ok_button = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel_button = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok_button.setStyleSheet("font-size: 12px; height: 18px;")
    cancel_button.setStyleSheet("font-size: 12px; height: 18px;")
    buttons_layout.addStretch(1)
    buttons_layout.addWidget(ok_button)
    buttons_layout.addSpacing(25)
    buttons_layout.addWidget(cancel_button)
    buttons_layout.addStretch(1)
    layout.addLayout(buttons_layout)
    dialog.setLayout(layout)
    accepted = [False]
    def on_accept():
        accepted[0] = True
        dialog.accept()
    ok_button.clicked.connect(on_accept)
    cancel_button.clicked.connect(dialog.reject)
    if dialog.exec() == QDialog.DialogCode.Accepted and accepted[0]:
        conf_level = float(conf_spin.value()) / 100.0
        plot_mode = mode_cb.currentData()
        return spin.value(), True, conf_level, plot_mode
    return None, False, 0.95, "orig_cont"
@safe_exec
def show_bj_forecast(main_window):
    result = getattr(main_window, "last_arima_result", None)
    if result is None:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Primero debe estimar un modelo en la etapa 2."))
        return
    steps, ok, conf_level, plot_mode = show_forecast_steps_dialog(main_window, default_value=3, min_value=1, max_value=120)
    if not ok:
        return
    conf_level = float(conf_level)
    conf_level = max(0.01, min(0.99, conf_level))
    pct = int(round(conf_level * 100))
    try:
        forecast = result.get_forecast(steps=steps)
        pred = forecast.predicted_mean
        conf_int = forecast.conf_int(alpha=1-conf_level)
        plt.figure(figsize=(8,3))
        serie_real = None
        try:
            if hasattr(result, "data") and hasattr(result.data, "endog"):
                serie_real = pd.Series(result.data.endog, index=(result.data.row_labels if hasattr(result.data, "row_labels") else None))
        except Exception:
            serie_real = None
        fitted_series = None
        try:
            if hasattr(result, "fittedvalues"):
                if hasattr(result.fittedvalues, "index"):
                    fitted_series = pd.Series(result.fittedvalues, index=result.fittedvalues.index)
                elif serie_real is not None:
                    fitted_series = pd.Series(result.fittedvalues, index=serie_real.index[:len(result.fittedvalues)])
                else:
                    fitted_series = pd.Series(result.fittedvalues)
        except Exception:
            fitted_series = None
        ax = plt.gca()
        show_forecast_legend = (plot_mode != "orig_fit_pred")
        if plot_mode == "only_pred":
            pred.plot(ax=ax, label=(QCoreApplication.translate("MainWindow", "Pronóstico") if show_forecast_legend else "_nolegend_"), color="#E45922")
            ax.fill_between(conf_int.index, conf_int.iloc[:,0], conf_int.iloc[:,1], color="#E45922", alpha=0.2, label=("_nolegend_"))
        elif plot_mode == "orig_cont":
            if serie_real is not None:
                serie_real.plot(ax=ax, label=QCoreApplication.translate("MainWindow", "Serie real"), color="#2B90B9")
            pred.plot(ax=ax, label=(QCoreApplication.translate("MainWindow", "Pronóstico") if show_forecast_legend else "_nolegend_"), color="#E45922")
            ax.fill_between(conf_int.index, conf_int.iloc[:,0], conf_int.iloc[:,1], color="#E45922", alpha=0.2, label=("_nolegend_"))
        elif plot_mode == "orig_fit_pred":
            if serie_real is not None:
                serie_real.plot(ax=ax, label=QCoreApplication.translate("MainWindow", "Serie real"), color="#217AD4")
            if fitted_series is not None:
                fitted_series.plot(ax=ax, label=QCoreApplication.translate("MainWindow", "Serie ajustada"), color="#E45922")
            pred.plot(ax=ax, label="_nolegend_", color="#E45922")
            ax.fill_between(conf_int.index, conf_int.iloc[:,0], conf_int.iloc[:,1], color="#E45922", alpha=0.2, label="_nolegend_")
        plt.title(QCoreApplication.translate("MainWindow", "Pronóstico a {steps} pasos con un {pct}% de confianza").format(steps=steps, pct=pct))
        handles, labels = ax.get_legend_handles_labels()
        if handles:
            ax.legend(handles, labels, loc='upper left', bbox_to_anchor=(1.02, 1), borderaxespad=0)
        plt.tight_layout()
        plt.subplots_adjust(right=0.75)
        plt.show()
        forecast_table = []
        for i in range(len(pred)):
            idx = pred.index[i]
            if hasattr(idx, 'date'):
                idx_str = str(idx.date())
            elif hasattr(idx, 'strftime'):
                idx_str = idx.strftime("%Y-%m-%d")
            else:
                idx_str = str(idx)
            forecast_table.append([
                idx_str,
                f"{pred.iloc[i]:.4f}",
                f"{conf_int.iloc[i,0]:.4f}",
                f"{conf_int.iloc[i,1]:.4f}"
            ])
        title_text = QCoreApplication.translate("MainWindow", "Pronóstico a {steps} pasos con un {pct}% de confianza.").format(steps=steps, pct=pct)
        forecast_html = f"""
        <div style='font-weight:bold; font-size:1.1em; margin-bottom:8px'>
            {title_text}
        </div>
        <table style='{tabla_html_style()}'>
            <tr>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Fecha")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Pronóstico")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Límite Inferior")}</th>
                <th style='{th_style()}'>{QCoreApplication.translate("MainWindow", "Límite Superior")}</th>
            </tr>
            {''.join(
                f"<tr><td style='{td_style()}'>{row[0]}</td>"
                f"<td style='{td_style()}'>{row[1]}</td>"
                f"<td style='{td_style()}'>{row[2]}</td>"
                f"<td style='{td_style()}'>{row[3]}</td></tr>"
                for row in forecast_table
            )}
        </table>
        <p style='margin-bottom: 200px;'></p>
        """
        main_window.result_area.append(forecast_html)
        QTimer.singleShot(0, main_window.scroll_result_area_to_end)
    except Exception as e:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "No se pudo generar el pronóstico: {error}").format(error=str(e)))
@safe_exec
def show_bj_preprocessing(main_window):
    tiempo_col_name, serie_col_name = show_ts_column_selection_dialog(main_window, QCoreApplication.translate("MainWindow", "Transformar y diferenciar la serie"))
    if not serie_col_name:
        return
    tiempo_col, serie_col, model = None, None, main_window.table.model()
    for col in range(model.columnCount()):
        header = model.headerData(col, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
        if header:
            if header == serie_col_name: serie_col = col
            if tiempo_col_name and header == tiempo_col_name: tiempo_col = col
    data, tiempos = [], []
    for row in range(model.rowCount()):
        item = model.data(model.index(row, serie_col), Qt.ItemDataRole.DisplayRole)
        if item is not None and str(item).strip() != "":
            try:
                data.append(float(item))
                if tiempo_col is not None:
                    tiempo_item = model.data(model.index(row, tiempo_col), Qt.ItemDataRole.DisplayRole)
                    tiempos.append(str(tiempo_item) if tiempo_item is not None else "")
            except Exception: pass
    if len(data) < 10:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "La serie debe tener al menos 10 datos numéricos."))
        return
    if tiempo_col is not None and len(tiempos) == len(data):
        fechas = pd.to_datetime(tiempos, errors='coerce')
        serie = pd.Series(data, index=fechas).dropna()
    else:
        serie = pd.Series(data)
    dialog = QDialog(main_window)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Preprocesamiento de la serie"))
    layout = QVBoxLayout(dialog)
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    freq_rule = None
    freq_cb = None
    if isinstance(serie.index, pd.DatetimeIndex):
        detected_freq = serie.index.inferred_freq
        freq_row_layout = QHBoxLayout()
        freq_label = QLabel(QCoreApplication.translate("MainWindow", "Frecuencia de la serie:"))
        freq_cb = QComboBox()
        freq_cb.setFixedHeight(40)
        freq_options = [
            (QCoreApplication.translate("MainWindow", "Diaria"), "D"),
            (QCoreApplication.translate("MainWindow", "Semanal"), "W-MON"),
            (QCoreApplication.translate("MainWindow", "Mensual"), "MS"),
            (QCoreApplication.translate("MainWindow", "Trimestral"), "QS"),
            (QCoreApplication.translate("MainWindow", "Cuatrimestral"), "4MS"),
            (QCoreApplication.translate("MainWindow", "Anual"), "YS"),
        ]
        det_norm = normalize_freq_code(detected_freq) if detected_freq is not None else None
        standard_norms = [normalize_freq_code(rule) for _, rule in freq_options]
        if det_norm and det_norm not in standard_norms:
            freq_options.insert(0, (frecuencia_amigable(detected_freq), detected_freq))
        for label, rule in freq_options:
            freq_cb.addItem(label, userData=rule)
        if det_norm:
            for i in range(freq_cb.count()):
                item_data = freq_cb.itemData(i)
                if normalize_freq_code(item_data) == det_norm:
                    freq_cb.setCurrentIndex(i)
                    break
        freq_row_layout.addWidget(freq_label)
        freq_row_layout.addWidget(freq_cb)
        layout.addLayout(freq_row_layout)
        layout.addSpacing(8)
        def update_freq():
            nonlocal serie, freq_rule
            freq_rule = freq_cb.currentData()
            if freq_rule and normalize_freq_code(freq_rule) != normalize_freq_code(detected_freq):
                try:
                    serie = serie.asfreq(freq_rule)
                except Exception as e:
                    QMessageBox.warning(
                        main_window,
                        "EVAR Stat",
                        QCoreApplication.translate(
                            "MainWindow",
                            "No se pudo cambiar la frecuencia: {error}"
                        ).format(error=e)
                    )
                    return
        freq_cb.currentIndexChanged.connect(update_freq)
        update_freq() 
    transform_row = QHBoxLayout()
    transform_label = QLabel(QCoreApplication.translate("MainWindow", "Transformar la serie:"))
    transform_combo = QComboBox()
    transform_combo.setFixedHeight(40)
    transform_combo.addItems([
        QCoreApplication.translate("MainWindow", "Ninguna"),
        QCoreApplication.translate("MainWindow", "Logarítmica"),
        QCoreApplication.translate("MainWindow", "Raíz cuadrada"),
        "Box-Cox",
    ])
    transform_row.addWidget(transform_label)
    transform_row.addWidget(transform_combo)
    layout.addLayout(transform_row)
    layout.addSpacing(8)
    diff_row = QHBoxLayout()
    diff_label = QLabel(QCoreApplication.translate("MainWindow", "Número de diferencias:"))
    diff_spin = QSpinBox()
    diff_spin.setMinimum(0)
    diff_spin.setMaximum(3)
    diff_spin.setValue(0)
    diff_spin.setFixedHeight(40)
    diff_row.addWidget(diff_label)
    diff_row.addWidget(diff_spin)
    layout.addLayout(diff_row)
    layout.addSpacing(8)
    buttons_layout = QHBoxLayout()
    ok_button = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel_button = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok_button.setStyleSheet("font-size: 12px; height: 18px;")
    cancel_button.setStyleSheet("font-size: 12px; height: 18px;")
    buttons_layout.addStretch(1)
    buttons_layout.addWidget(ok_button)
    buttons_layout.addSpacing(25)
    buttons_layout.addWidget(cancel_button)
    buttons_layout.addStretch(1)
    layout.addLayout(buttons_layout)
    dialog.setLayout(layout)
    accepted = [False]
    def on_accept():
        accepted[0] = True
        dialog.accept()
    ok_button.clicked.connect(on_accept)
    cancel_button.clicked.connect(dialog.reject)
    if not dialog.exec() or not accepted[0]:
        return
    serie_proc = serie.copy()
    trans = transform_combo.currentText()
    if QCoreApplication.translate("MainWindow", "Logarítmica") in trans:
        serie_proc = np.log(serie_proc.replace(0, np.nan).dropna())
    elif QCoreApplication.translate("MainWindow", "Raíz cuadrada") in trans:
        serie_proc = np.sqrt(serie_proc)
    elif "Box-Cox" in trans:
        serie_proc, _ = boxcox(serie_proc + 1e-6)
        serie_proc = pd.Series(serie_proc, index=serie.index[-len(serie_proc):])
    d = diff_spin.value()
    if d > 0:
        serie_proc = serie_proc.diff(d).dropna()
    plt.figure(figsize=(8,3))
    plt.plot(serie_proc)
    titulo = (serie_col_name)
    if "Ninguna" not in trans:
        titulo += QCoreApplication.translate(
            "MainWindow",
            " transformada ({trans})"
        ).format(trans=trans)
    if d > 0:
        if "Ninguna" not in trans:
            titulo += QCoreApplication.translate(
                "MainWindow",
                " y diferenciada ({d})"
            ).format(d=d)
        else:
            titulo += QCoreApplication.translate(
                "MainWindow",
                " diferenciada ({d})"
            ).format(d=d)
    plt.title(QCoreApplication.translate("MainWindow", titulo))
    plt.tight_layout()
    plt.show()
    df = model._df.copy()
    col_name = serie_col_name
    if QCoreApplication.translate("MainWindow", "Logarítmica") in trans:
        col_name += "_Log"
    elif QCoreApplication.translate("MainWindow", "Raíz cuadrada") in trans:
        col_name += "_Raíz"
    elif "Box-Cox" in trans:
        col_name += "_BoxCox"
    if d > 0:
        col_name += f"_diff({d})"
    df[col_name] = ""
    serie_proc_values = serie_proc.values
    for i in range(min(len(df), len(serie_proc_values))):
        df.at[i, col_name] = serie_proc_values[i]
    model_new = PandasModel(df, parent=main_window.table)
    main_window.table.setModel(model_new)
    if hasattr(main_window, "update_occupied_counters"):
        model_new.dataChanged.connect(main_window.update_occupied_counters)
    if hasattr(main_window, "update_selection_count"):
        model_new.dataChanged.connect(main_window.update_selection_count)
        if main_window.table.selectionModel():
            main_window.table.selectionModel().selectionChanged.connect(main_window.update_selection_count)
        main_window.update_selection_count()
    if hasattr(main_window, "update_occupied_counters"):
        main_window.update_occupied_counters()
@safe_exec
def show_generate_date_column(main_window):
    model = main_window.table.model()
    try:
        df = model._df.copy()
    except Exception:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "No se pudo acceder a los datos de la tabla."))
        return
    n_rows = len(df)
    dialog = QDialog(main_window)
    dialog.setWindowTitle(QCoreApplication.translate("MainWindow", "Generar columna de fechas"))
    v = QVBoxLayout(dialog)
    v.setContentsMargins(20, 20, 20, 20)
    v.setSpacing(5)
    name_row = QHBoxLayout()
    name_lbl = QLabel(QCoreApplication.translate("MainWindow", "Nombre de columna:"))
    name_edit = QLineEdit()
    name_edit.setFixedHeight(40)
    name_edit.setText(QCoreApplication.translate("MainWindow", "Fecha"))
    name_row.addWidget(name_lbl)
    name_row.addWidget(name_edit)
    v.addLayout(name_row)
    v.addSpacing(8)
    start_row = QHBoxLayout()
    start_lbl = QLabel(QCoreApplication.translate("MainWindow", "Fecha de inicio:"))
    start_de = QDateEdit()
    start_de.setCalendarPopup(True)
    start_de.setFixedHeight(40)
    start_de.setDate(start_de.date().currentDate())
    start_row.addWidget(start_lbl)
    start_row.addWidget(start_de)
    v.addLayout(start_row)
    v.addSpacing(8)
    freq_row = QHBoxLayout()
    freq_lbl = QLabel(QCoreApplication.translate("MainWindow", "Frecuencia de serie:"))
    freq_cb = QComboBox()
    freq_cb.setFixedHeight(40)
    freq_options = [
        (QCoreApplication.translate("MainWindow", "Diaria"), "D"),
        (QCoreApplication.translate("MainWindow", "Semanal"), "W-MON"),
        (QCoreApplication.translate("MainWindow", "Mensual"), "MS"),
        (QCoreApplication.translate("MainWindow", "Trimestral"), "QS"),
        (QCoreApplication.translate("MainWindow", "Cuatrimestral"), "4MS"),
        (QCoreApplication.translate("MainWindow", "Anual"), "YS"),
    ]
    for label, rule in freq_options:
        freq_cb.addItem(label, userData=rule)
    freq_row.addWidget(freq_lbl)
    freq_row.addWidget(freq_cb)
    v.addLayout(freq_row)
    v.addSpacing(8)
    len_row = QHBoxLayout()
    len_lbl = QLabel(QCoreApplication.translate("MainWindow", "Número de períodos:"))
    len_sb = QSpinBox()
    len_sb.setMinimum(1)
    len_sb.setMaximum(100000)
    len_sb.setValue(max(1, n_rows or 12))
    len_sb.setFixedHeight(40)
    len_row.addWidget(len_lbl)
    len_row.addWidget(len_sb)
    v.addLayout(len_row)
    btns = QHBoxLayout()
    ok = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    ok.setStyleSheet("font-size: 12px; height: 18px;")
    cancel.setStyleSheet("font-size: 12px; height: 18px;")
    btns.addStretch(1); btns.addWidget(ok); btns.addSpacing(25); btns.addWidget(cancel); btns.addStretch(1)
    v.addSpacing(8); v.addLayout(btns)
    ok.clicked.connect(dialog.accept)
    cancel.clicked.connect(dialog.reject)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return
    col_name = name_edit.text().strip() or QCoreApplication.translate("MainWindow", "Fecha")
    start_date = start_de.date().toPyDate()
    freq = freq_cb.currentData()
    periods = len_sb.value()
    try:
        rng = pd.date_range(start=start_date, periods=periods, freq=freq)
        if periods > n_rows:
            df = df.reindex(range(periods)).fillna("").copy()
        df[col_name] = ""
        for i in range(periods):
            df.at[i, col_name] = str(rng[i].date()) if hasattr(rng[i], "date") else str(rng[i])
        model_new = PandasModel(df, parent=main_window.table)
        main_window.table.setModel(model_new)
        if hasattr(main_window, "update_occupied_counters"):
            model_new.dataChanged.connect(main_window.update_occupied_counters)
        if hasattr(main_window, "update_selection_count"):
            model_new.dataChanged.connect(main_window.update_selection_count)
            if main_window.table.selectionModel():
                main_window.table.selectionModel().selectionChanged.connect(main_window.update_selection_count)
            main_window.update_selection_count()
        if hasattr(main_window, "update_occupied_counters"):
            main_window.update_occupied_counters()
        QMessageBox.information(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "Columna de fechas generada correctamente."))
    except Exception as e:
        QMessageBox.warning(main_window, "EVAR Stat", QCoreApplication.translate("MainWindow", "No se pudo generar la columna de fechas: {error}").format(error=e))

def show_ts_column_selection_dialog(main_window, title="Seleccionar columnas de serie de tiempo"):
    dialog = QDialog(main_window)
    dialog.setWindowTitle(title)
    layout = QVBoxLayout()
    layout.setContentsMargins(20, 20, 20, 20)
    layout.setSpacing(5)
    main_layout = QHBoxLayout()
    model = main_window.table.model()
    all_columns_list = DraggableListWidget()
    all_columns_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection)
    for col in range(model.columnCount()):
        header = model.headerData(col, Qt.Orientation.Horizontal, Qt.ItemDataRole.DisplayRole)
        if header and not header.isdigit():
            all_columns_list.addItem(str(header))
    all_columns_frame = QFrame()
    all_columns_frame.setLayout(QVBoxLayout())
    all_columns_frame.layout().addWidget(all_columns_list)
    all_columns_frame.setFrameShape(QFrame.Shape.Box)
    all_columns_frame.setFrameShadow(QFrame.Shadow.Sunken)
    all_columns_frame.setStyleSheet("QFrame { border: 1px solid #2B90B9; border-radius: 0px; }")
    all_columns_frame.setFixedHeight(250)
    main_layout.addWidget(all_columns_frame)
    toggle_column_button_serie = QPushButton()
    toggle_column_button_serie.setFixedSize(30, 30)
    toggle_column_button_serie.setIcon(QIcon(resource_path("Iconos/right.png")))
    toggle_column_button_serie.setIconSize(QSize(22, 22))
    toggle_column_button_time = QPushButton()
    toggle_column_button_time.setFixedSize(30, 30)
    toggle_column_button_time.setIcon(QIcon(resource_path("Iconos/right.png")))
    toggle_column_button_time.setIconSize(QSize(22, 22))
    buttons_layout = QVBoxLayout()
    buttons_layout.addStretch(2)  
    buttons_layout.addWidget(toggle_column_button_serie)
    buttons_layout.addStretch(3) 
    buttons_layout.addWidget(toggle_column_button_time)
    buttons_layout.addStretch(1) 
    main_layout.addLayout(buttons_layout)
    selected_columns_layout = QVBoxLayout()
    dependent_column_layout = QVBoxLayout()
    dependent_column_label = QLabel(QCoreApplication.translate("MainWindow", "Serie:"))
    dependent_column_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    dependent_column_layout.addWidget(dependent_column_label)
    selected_serie_column_list = DraggableListWidget()
    selected_serie_column_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection) 
    selected_dependent_columns_frame = QFrame()
    selected_dependent_columns_frame.setLayout(QVBoxLayout())
    selected_dependent_columns_frame.layout().addWidget(selected_serie_column_list)
    selected_dependent_columns_frame.setFrameShape(QFrame.Shape.Box)
    selected_dependent_columns_frame.setFrameShadow(QFrame.Shadow.Sunken)
    selected_dependent_columns_frame.setStyleSheet("QFrame { border: 1px solid #2B90B9; border-radius: 0px; }")
    selected_dependent_columns_frame.setFixedHeight(90)
    dependent_column_layout.addWidget(selected_dependent_columns_frame)
    selected_columns_layout.addLayout(dependent_column_layout)
    independent_columns_layout = QVBoxLayout()
    independent_columns_label = QLabel(QCoreApplication.translate("MainWindow", "Tiempo:"))
    independent_columns_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
    independent_columns_layout.addWidget(independent_columns_label)
    selected_time_column_list = DraggableListWidget()
    selected_time_column_list.setSelectionMode(QListWidget.SelectionMode.ExtendedSelection) 
    selected_independent_columns_frame = QFrame()
    selected_independent_columns_frame.setLayout(QVBoxLayout())
    selected_independent_columns_frame.layout().addWidget(selected_time_column_list)
    selected_independent_columns_frame.setFrameShape(QFrame.Shape.Box)
    selected_independent_columns_frame.setFrameShadow(QFrame.Shadow.Sunken)
    selected_independent_columns_frame.setStyleSheet("QFrame { border: 1px solid #2B90B9; border-radius: 0px; }")
    selected_independent_columns_frame.setFixedHeight(90)
    independent_columns_layout.addWidget(selected_independent_columns_frame)
    selected_columns_layout.addLayout(independent_columns_layout)
    main_layout.addLayout(selected_columns_layout)
    layout.addLayout(main_layout)
    def handle_all_list_selection():
        if all_columns_list.selectedItems():
            selected_time_column_list.clearSelection()
            selected_serie_column_list.clearSelection()
    def handle_time_list_selection():
        if selected_time_column_list.selectedItems():
            all_columns_list.clearSelection()
            selected_serie_column_list.clearSelection()
    def handle_serie_list_selection():
        if selected_serie_column_list.selectedItems():
            all_columns_list.clearSelection()
            selected_time_column_list.clearSelection()
    all_columns_list.itemSelectionChanged.connect(handle_all_list_selection)
    selected_time_column_list.itemSelectionChanged.connect(handle_time_list_selection)
    selected_serie_column_list.itemSelectionChanged.connect(handle_serie_list_selection)
    def move_selected_time_item():
        if all_columns_list.selectedItems():
            selected = all_columns_list.selectedItems()
            for item in selected:
                items_in_serie = selected_serie_column_list.findItems(item.text(), Qt.MatchFlag.MatchExactly)
                for s_item in items_in_serie:
                    selected_serie_column_list.takeItem(selected_serie_column_list.row(s_item))
                selected_time_column_list.clear()
                selected_time_column_list.addItem(item.text())
                all_columns_list.takeItem(all_columns_list.row(item))
        elif selected_time_column_list.selectedItems():
            selected = selected_time_column_list.selectedItems()
            for item in selected:
                all_columns_list.addItem(item.text())
                selected_time_column_list.takeItem(selected_time_column_list.row(item))
        update_toggle_time_button_icon()
    def move_selected_serie_item():
        if all_columns_list.selectedItems():
            selected = all_columns_list.selectedItems()
            for item in selected:
                items_in_time = selected_time_column_list.findItems(item.text(), Qt.MatchFlag.MatchExactly)
                for t_item in items_in_time:
                    selected_time_column_list.takeItem(selected_time_column_list.row(t_item))
                selected_serie_column_list.clear()
                selected_serie_column_list.addItem(item.text())
                all_columns_list.takeItem(all_columns_list.row(item))
        elif selected_serie_column_list.selectedItems():
            selected = selected_serie_column_list.selectedItems()
            for item in selected:
                all_columns_list.addItem(item.text())
                selected_serie_column_list.takeItem(selected_serie_column_list.row(item))
        update_toggle_serie_button_icon()
    def update_toggle_time_button_icon():
        if all_columns_list.selectedItems():
            toggle_column_button_time.setIcon(QIcon(resource_path("Iconos/right.png")))
        elif selected_time_column_list.selectedItems():
            toggle_column_button_time.setIcon(QIcon(resource_path("Iconos/left.png")))
        else:
            toggle_column_button_time.setIcon(QIcon(resource_path("Iconos/right.png")))
    def update_toggle_serie_button_icon():
        if all_columns_list.selectedItems():
            toggle_column_button_serie.setIcon(QIcon(resource_path("Iconos/right.png")))
        elif selected_serie_column_list.selectedItems():
            toggle_column_button_serie.setIcon(QIcon(resource_path("Iconos/left.png")))
        else:
            toggle_column_button_serie.setIcon(QIcon(resource_path("Iconos/right.png")))
    toggle_column_button_time.clicked.connect(move_selected_time_item)
    toggle_column_button_serie.clicked.connect(move_selected_serie_item)
    all_columns_list.itemSelectionChanged.connect(update_toggle_time_button_icon)
    all_columns_list.itemSelectionChanged.connect(update_toggle_serie_button_icon)
    selected_time_column_list.itemSelectionChanged.connect(update_toggle_time_button_icon)
    selected_serie_column_list.itemSelectionChanged.connect(update_toggle_serie_button_icon)
    def reset_columns():
        while selected_time_column_list.count() > 0:
            item = selected_time_column_list.takeItem(0)
            all_columns_list.addItem(item.text())
        while selected_serie_column_list.count() > 0:
            item = selected_serie_column_list.takeItem(0)
            all_columns_list.addItem(item.text())
    button_box = QDialogButtonBox() 
    ok_button = QPushButton(QCoreApplication.translate("MainWindow", "Aceptar"))
    cancel_button = QPushButton(QCoreApplication.translate("MainWindow", "Cancelar"))
    reset_button = QPushButton(QCoreApplication.translate("MainWindow", "Restablecer"))
    ok_button.setStyleSheet("font-size: 12px; height: 18px;")
    cancel_button.setStyleSheet("font-size: 12px; height: 18px;")
    reset_button.setStyleSheet("font-size: 12px; height: 18px;")
    button_box.addButton(ok_button, QDialogButtonBox.ButtonRole.AcceptRole)
    button_box.addButton(cancel_button, QDialogButtonBox.ButtonRole.RejectRole)
    button_box.addButton(reset_button, QDialogButtonBox.ButtonRole.ResetRole)
    reset_button.clicked.connect(reset_columns)
    cancel_button.clicked.connect(dialog.reject)
    buttons_layout = QHBoxLayout()
    buttons_layout.addStretch(1)
    buttons_layout.addWidget(ok_button)
    buttons_layout.addWidget(cancel_button)
    buttons_layout.addWidget(reset_button)
    buttons_layout.setSpacing(25)
    buttons_layout.addStretch(1)
    layout.addLayout(main_layout) 
    layout.addSpacing(8)
    layout.addLayout(buttons_layout)
    dialog.setLayout(layout)
    def on_ok():
        serie = selected_serie_column_list.item(0).text() if selected_serie_column_list.count() > 0 else None
        tiempo = selected_time_column_list.item(0).text() if selected_time_column_list.count() > 0 else None
        if not serie or not tiempo:
            QMessageBox.warning(
                dialog,
                "EVAR Stat",
                QCoreApplication.translate("MainWindow", "Debes seleccionar tanto la serie como el tiempo.")
            )
            return
        dialog.accept()
        dialog.selected_serie = serie
        dialog.selected_tiempo = tiempo
    ok_button.clicked.connect(on_ok)
    cancel_button.clicked.connect(dialog.reject)
    if dialog.exec() == QDialog.DialogCode.Accepted:
        return dialog.selected_tiempo, dialog.selected_serie
    return None, None

_plugin_translator = None
def load_plugin_translator():
    global _plugin_translator
    settings = QSettings("EVARStat", "EVARStatApp")
    lang = settings.value("language", "es")
    qm_path = os.path.join(os.path.dirname(__file__), f"{lang}.qm")
    if os.path.exists(qm_path):
        translator = QTranslator()
        if translator.load(qm_path):
            if _plugin_translator:
                QCoreApplication.instance().removeTranslator(_plugin_translator)
            QCoreApplication.instance().installTranslator(translator)
            _plugin_translator = translator
load_plugin_translator()